package com.tacticaltalk.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Testes automáticos do teclado numérico "multitoque" (nomes e palavras-passe dos canais). */
class TextEditorTest {
    @Test
    fun toquesRepetidosPercorremAsLetras() {
        val e = TextEditor()
        e.tap(4, 0); assertEquals("G", e.text)
        e.tap(4, 100); assertEquals("H", e.text)
        e.tap(4, 200); assertEquals("I", e.text)
        e.tap(4, 300); assertEquals("4", e.text)
        e.tap(4, 400); assertEquals("G", e.text) // volta ao início
    }

    @Test
    fun outraTeclaOuTempoAcrescentaCaracter() {
        val e = TextEditor()
        e.tap(4, 0); e.tap(4, 100)          // H
        e.tap(3, 200)                       // outra tecla: novo carácter (minúscula)
        e.tap(3, 300)                       // E
        assertEquals("He", e.text)
        e.tap(3, 2000)                      // passou o tempo: novo carácter
        assertEquals("Hed", e.text)
    }

    @Test
    fun espacoEMaiusculaAposEspaco() {
        val e = TextEditor()
        e.tap(2, 0)                         // A
        e.tap(0, 1000)                      // espaço
        e.tap(5, 2000)                      // J (maiúscula depois de espaço)
        assertEquals("A J", e.text)
    }

    @Test
    fun apagarLimparELimite() {
        val e = TextEditor(max = 3)
        assertTrue(e.tap(2, 0)); assertTrue(e.tap(3, 1000)); assertTrue(e.tap(4, 2000))
        assertFalse(e.tap(5, 3000))         // limite atingido
        e.backspace(); assertEquals(2, e.text.length)
        e.clear(); assertEquals("", e.text)
    }

    @Test
    fun resultadoSemEspacosRepetidos() {
        val e = TextEditor("  Obra   Norte  ", 16)
        assertEquals("Obra Norte", e.result())
    }

    @Test
    fun palavraPasseDistingueMaiusculasComAlternador() {
        val e = TextEditor(max = 12, autoCap = false)
        e.tap(2, 0); assertEquals("a", e.text)
        e.toggleCase(); e.tap(3, 2000); assertEquals("aD", e.text)
    }
}
