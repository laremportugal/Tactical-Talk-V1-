package com.tacticaltalk.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Testes automáticos da cifra e da deteção de duplicados (correm no GitHub Actions, sem telemóvel). */
class CoreTest {
    @Test
    fun cifraIdaEVolta() {
        val k = Crypto.deriveKey("segredo", 2)!!
        val aad = Crypto.aad(3, 2, 111, 222, 5)
        val ct = Crypto.seal(k, "ola".toByteArray(), aad)
        assertEquals("ola", String(Crypto.open(k, ct, aad)!!))
    }

    @Test
    fun codigoErradoFalha() {
        val aad = Crypto.aad(3, 2, 1, 1, 1)
        val ct = Crypto.seal(Crypto.deriveKey("certo", 2)!!, ByteArray(10), aad)
        assertNull(Crypto.open(Crypto.deriveKey("errado", 2)!!, ct, aad))
    }

    @Test
    fun cabecalhoAdulteradoFalha() {
        val k = Crypto.deriveKey("x", 1)!!
        val ct = Crypto.seal(k, ByteArray(10), Crypto.aad(3, 1, 1, 1, 1))
        assertNull(Crypto.open(k, ct, Crypto.aad(3, 1, 2, 1, 1)))
    }

    @Test
    fun canaisDiferentesTemChavesDiferentes() {
        val aad = Crypto.aad(3, 1, 1, 1, 1)
        val ct = Crypto.seal(Crypto.deriveKey("mesmo", 1)!!, ByteArray(4), aad)
        assertNull(Crypto.open(Crypto.deriveKey("mesmo", 2)!!, ct, aad))
    }

    @Test
    fun semCodigoSemChave() {
        assertNull(Crypto.deriveKey("", 1))
        assertNotNull(Crypto.deriveKey("a", 1))
    }

    @Test
    fun duplicadosSaoDescartados() {
        val c = SeenCache(10)
        assertTrue(c.firstTime(1, 2, 3, 3))
        assertFalse(c.firstTime(1, 2, 3, 3))
        assertTrue(c.firstTime(1, 2, 4, 3))
    }

    @Test
    fun cacheEsqueceOsMaisAntigos() {
        val c = SeenCache(3)
        for (i in 1..5) c.firstTime(1, 1, i, 3)
        assertTrue(c.firstTime(1, 1, 1, 3)) // já foi esquecido
        assertFalse(c.firstTime(1, 1, 5, 3))
    }

    @Test
    fun nivelDeAudio() {
        assertEquals(0f, pcmLevel(ByteArray(640)), 0.0001f)
        val loud = ByteArray(640)
        for (i in 0 until 320) {
            val v = if (i % 2 == 0) 12000 else -12000
            loud[2 * i] = (v and 0xff).toByte()
            loud[2 * i + 1] = ((v shr 8) and 0xff).toByte()
        }
        assertTrue(pcmLevel(loud) > 0.9f)
    }

    @Test
    fun transportesTemNomes() {
        assertEquals("Bluetooth", Transport.BLUETOOTH.label)
        assertEquals("Wi-Fi Direct", Transport.WIFI_DIRECT.label)
        assertEquals("Hotspot", Transport.HOTSPOT.label)
    }
}
