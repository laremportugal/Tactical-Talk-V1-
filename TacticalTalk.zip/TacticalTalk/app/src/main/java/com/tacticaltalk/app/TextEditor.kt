package com.tacticaltalk.app

/**
 * Introdução de texto "à antiga" (várias letras por tecla, toques sucessivos), sem Android:
 * é puro Kotlin e por isso testável. 2 = A B C 2 · 3 = D E F 3 · ... · 7 = P Q R S 7 · 9 = W X Y Z 9 ·
 * 1 = . , ? ! - 1 · 0 = espaço e 0. Toques na MESMA tecla em menos de [timeoutMs] percorrem as letras.
 */
class TextEditor(initial: String = "", val max: Int = 16, private val autoCap: Boolean = true) {

    companion object {
        val MAP = arrayOf(" 0", ".,?!-1", "ABC2", "DEF3", "GHI4", "JKL5", "MNO6", "PQRS7", "TUV8", "WXYZ9")
        const val TIMEOUT_MS = 900L
    }

    var text: String = initial.take(max)
        private set
    private var pendingKey = -1
    private var pendingIdx = 0
    private var pendingAt = 0L
    private var upper = false // só usado quando autoCap = false (palavras-passe)

    val hasPending: Boolean get() = pendingKey >= 0

    private fun capNext(base: String): Boolean = if (autoCap) base.isEmpty() || base.last() == ' ' else upper

    private fun styled(c: Char, base: String): Char =
        if (c.isLetter()) (if (capNext(base)) c.uppercaseChar() else c.lowercaseChar()) else c

    /** Devolve false se o texto já está no limite e a tecla não pode acrescentar mais. */
    fun tap(digit: Int, now: Long): Boolean {
        if (digit !in 0..9) return false
        val chars = MAP[digit]
        if (pendingKey == digit && now - pendingAt <= TIMEOUT_MS && text.isNotEmpty()) {
            pendingIdx = (pendingIdx + 1) % chars.length
            val base = text.dropLast(1)
            text = base + styled(chars[pendingIdx], base)
        } else {
            pendingKey = -1
            if (text.length >= max) return false
            pendingKey = digit
            pendingIdx = 0
            text += styled(chars[0], text)
        }
        pendingAt = now
        return true
    }

    fun commit() {
        pendingKey = -1
    }

    fun backspace() {
        pendingKey = -1
        if (text.isNotEmpty()) text = text.dropLast(1)
    }

    fun clear() {
        pendingKey = -1
        text = ""
    }

    fun toggleCase() {
        if (!autoCap) upper = !upper
    }

    /** Texto final: sem espaços nas pontas e sem espaços repetidos. */
    fun result(): String = text.trim().replace(Regex(" +"), " ")

    /** Há uma letra pendente que ainda pode mudar com mais um toque? */
    fun pendingLive(now: Long): Boolean = hasPending && now - pendingAt <= TIMEOUT_MS
}
