package com.tacticaltalk.app

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.sin

/**
 * Efeitos sonoros do rádio (tecla, confirmação, início/fim de transmissão, alerta, erro).
 * Cada som usa o seu próprio AudioTrack curto: nunca entra na fila da voz, por isso não a corta nem a substitui.
 */
object UiSounds {
    enum class S { KEY, OK, TX_START, TX_END, INCOMING, ERROR }

    private class Tone(val f: Double, val ms: Int, val gap: Int = 0, val amp: Double = 0.5, val square: Boolean = false)

    private val exec = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val cache = HashMap<S, ByteArray>()
    private const val RATE = 16000

    private fun build(s: S): ByteArray = when (s) {
        S.KEY -> pcm(Tone(1900.0, 22, amp = 0.35))
        S.OK -> pcm(Tone(1300.0, 40, 20), Tone(1800.0, 55))
        S.TX_START -> pcm(Tone(1500.0, 55, 45), Tone(1500.0, 55)) // "tim-tim"
        S.TX_END -> pcm(Tone(950.0, 70))
        S.INCOMING -> pcm(Tone(1100.0, 60, 30), Tone(1400.0, 60, 30), Tone(1800.0, 80))
        S.ERROR -> pcm(Tone(320.0, 160, amp = 0.35, square = true))
    }

    private fun pcm(vararg tones: Tone): ByteArray {
        var total = 0
        for (t in tones) total += (RATE * (t.ms + t.gap) / 1000)
        val bb = ByteBuffer.allocate(total * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (t in tones) {
            val n = RATE * t.ms / 1000
            val fade = RATE * 4 / 1000
            for (i in 0 until n) {
                var a = t.amp
                if (i < fade) a *= i.toDouble() / fade
                if (i > n - fade) a *= (n - i).toDouble() / fade
                var v = sin(2 * PI * t.f * i / RATE)
                if (t.square) v = if (v >= 0) 1.0 else -1.0
                bb.putShort((v * a * Short.MAX_VALUE).toInt().toShort())
            }
            repeat(RATE * t.gap / 1000) { bb.putShort(0) }
        }
        return bb.array()
    }

    fun play(ctx: Context, s: S) {
        if (!Prefs.radioSounds(ctx)) return
        val vol = Prefs.uiVolume(ctx) / 100f
        if (vol <= 0f) return
        exec.execute {
            try {
                val data = cache.getOrPut(s) { build(s) }
                val t = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setSampleRate(RATE)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(data.size)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                t.write(data, 0, data.size)
                t.setVolume(vol)
                t.play()
                val ms = data.size / 2 * 1000L / RATE
                main.postDelayed({
                    try {
                        t.release()
                    } catch (_: Exception) {
                    }
                }, ms + 150)
            } catch (_: Exception) {
            }
        }
    }
}
