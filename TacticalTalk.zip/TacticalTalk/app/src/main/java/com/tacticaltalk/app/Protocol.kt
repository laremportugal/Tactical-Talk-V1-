package com.tacticaltalk.app

import java.util.LinkedHashMap

/**
 * Protocolo TacticalTalk v2 (TCP, porta fixa). Cabeçalho de 20 bytes (big-endian):
 * magic(2) tipo(1) ttl(1) flags(1) canal(1) origem(4) txId(4) seq(4) tamanho(2) | payload
 *
 * - origem: identificador do dispositivo que gerou o pacote (não muda ao ser retransmitido)
 * - ttl: saltos restantes; cada repetidor desconta 1 (limite de saltos)
 * - (origem, txId, seq, tipo) identifica o pacote: duplicados são descartados (sem ciclos)
 * - payload: se o canal tiver código, é AES-128-GCM (nonce 12 bytes + cifra + etiqueta 16 bytes)
 */
object Protocol {
    const val PORT = 8988
    const val MAGIC = 0x5754
    const val VERSION = 2

    const val T_HELLO = 1
    const val T_TX_START = 2
    const val T_AUDIO = 3
    const val T_TX_END = 4
    const val T_BYE = 5
    const val T_PING = 6
    const val T_PONG = 7

    const val F_URGENT = 1
    const val F_CALL = 2

    const val DEFAULT_TTL = 3
    const val MAX_PAYLOAD = 2048

    const val SAMPLE_RATE = 16000
    const val FRAME_BYTES = 640 // 20 ms
}

class Packet(
    val type: Int,
    val ttl: Int,
    val flags: Int,
    val channel: Int,
    val src: Int,
    val tx: Int,
    val seq: Int,
    val payload: ByteArray
)

/** Memória curta de pacotes já vistos (evita duplicados e ciclos de retransmissão). */
class SeenCache(private val max: Int) {
    private val map = object : LinkedHashMap<Long, Boolean>() {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Long, Boolean>?): Boolean = size > max
    }

    @Synchronized
    fun firstTime(src: Int, tx: Int, seq: Int, type: Int): Boolean {
        var h = src.toLong()
        h = h * 1000003L + tx
        h = h * 1000003L + seq
        h = h * 31L + type
        if (map.containsKey(h)) return false
        map[h] = true
        return true
    }
}

/** Configuração dos sinais sonoros. */
object AudioConfig {
    const val BEEP_FREQ_HZ = 1400.0
    const val BEEP_MS = 90
    const val BEEP_GAP_MS = 70
    const val BEEP_COUNT = 2
    const val BEEP_AMPLITUDE = 0.6
    const val BEEP_TAIL_MS = 40

    // Alerta de URGÊNCIA: mais agudo, 3 toques
    const val ALERT_FREQ_HZ = 2200.0
    const val ALERT_MS = 130
    const val ALERT_GAP_MS = 60
    const val ALERT_COUNT = 3
}

/** Transportes locais suportados. */
enum class Transport(val label: String) {
    WIFI_DIRECT("Wi-Fi Direct"),
    HOTSPOT("Hotspot"),
    BLUETOOTH("Bluetooth")
}

/** Nível (0..1) de uma trama PCM 16 bit little-endian: medição real, usada na onda do ecrã. */
fun pcmLevel(b: ByteArray): Float {
    var sum = 0.0
    var n = 0
    var i = 0
    while (i + 1 < b.size) {
        val s = ((b[i + 1].toInt() shl 8) or (b[i].toInt() and 0xff)).toShort().toInt()
        sum += s.toDouble() * s
        n++
        i += 2
    }
    if (n == 0) return 0f
    return (Math.sqrt(sum / n) / 12000.0).toFloat().coerceIn(0f, 1f)
}
