package com.tacticaltalk.app

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.math.PI
import kotlin.math.sin

/**
 * Reprodução numa fila única: sinais ("pim-pim", alerta) e voz entram na MESMA fila e no MESMO
 * AudioTrack, por isso a ordem é garantida. Em modo chamada usa o canal de comunicação do Android
 * (permite ao sistema aplicar o cancelamento de eco).
 */
class AudioPlayer {
    private var track: AudioTrack? = null
    private var thread: Thread? = null
    private val queue = LinkedBlockingQueue<ByteArray>(500)
    @Volatile private var running = false
    @Volatile private var volume = 0.8f
    private val beep: ByteArray = tone(AudioConfig.BEEP_FREQ_HZ, AudioConfig.BEEP_MS, AudioConfig.BEEP_GAP_MS, AudioConfig.BEEP_COUNT, AudioConfig.BEEP_TAIL_MS)
    private val alert: ByteArray = tone(AudioConfig.ALERT_FREQ_HZ, AudioConfig.ALERT_MS, AudioConfig.ALERT_GAP_MS, AudioConfig.ALERT_COUNT, 40)

    fun start(callMode: Boolean = false) {
        if (running) return
        val min = AudioTrack.getMinBufferSize(
            Protocol.SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(if (callMode) AudioAttributes.USAGE_VOICE_COMMUNICATION else AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(Protocol.SAMPLE_RATE)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(min, Protocol.FRAME_BYTES * 8))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        t.setVolume(volume)
        t.play()
        track = t
        running = true
        thread = Thread({
            while (running) {
                val data = try {
                    queue.poll(200, TimeUnit.MILLISECONDS)
                } catch (e: InterruptedException) {
                    null
                } ?: continue
                t.write(data, 0, data.size)
            }
        }, "audio-player").also { it.start() }
    }

    fun setVolume(v: Float) {
        volume = v.coerceIn(0f, 1f)
        track?.setVolume(volume)
    }

    fun enqueue(pcm: ByteArray) {
        if (running) queue.offer(pcm)
    }

    fun playBeep() {
        if (running) queue.offer(beep)
    }

    fun playAlert() {
        if (running) queue.offer(alert)
    }

    /** Descarta áudio ainda não reproduzido (nova transmissão / urgência). */
    fun flush() {
        queue.clear()
    }

    fun stop() {
        running = false
        try {
            thread?.join(300)
        } catch (_: InterruptedException) {
        }
        try {
            track?.stop()
            track?.release()
        } catch (_: Exception) {
        }
        track = null
        thread = null
        queue.clear()
    }

    private fun tone(freq: Double, ms: Int, gapMs: Int, count: Int, tailMs: Int): ByteArray {
        val rate = Protocol.SAMPLE_RATE
        val n = rate * ms / 1000
        val gap = rate * gapMs / 1000
        val tail = rate * tailMs / 1000
        val total = count * n + (count - 1) * gap + tail
        val bb = ByteBuffer.allocate(total * 2).order(ByteOrder.LITTLE_ENDIAN)
        val fade = rate * 5 / 1000
        for (b in 0 until count) {
            for (i in 0 until n) {
                var a = AudioConfig.BEEP_AMPLITUDE
                if (i < fade) a *= i.toDouble() / fade
                if (i > n - fade) a *= (n - i).toDouble() / fade
                bb.putShort((sin(2 * PI * freq * i / rate) * a * Short.MAX_VALUE).toInt().toShort())
            }
            if (b < count - 1) repeat(gap) { bb.putShort(0) }
        }
        repeat(tail) { bb.putShort(0) }
        return bb.array()
    }
}
