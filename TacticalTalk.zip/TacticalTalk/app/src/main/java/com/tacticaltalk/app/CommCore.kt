package com.tacticaltalk.app

import android.bluetooth.BluetoothSocket
import android.content.Context
import android.location.LocationManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.location.LocationManagerCompat
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList
import javax.crypto.spec.SecretKeySpec
import kotlin.random.Random

/**
 * Dono de toda a comunicação (vive no processo, não na interface).
 *
 * Camada comum de ligações: cada vizinho pode ter VÁRIAS ligações (Wi-Fi Direct, hotspot, Bluetooth).
 * O áudio segue por UMA só ligação activa por vizinho (escolhida por métricas reais); as restantes ficam
 * em espera, a ser medidas. Os pacotes têm (origem, txId, seq): duplicados e ciclos são descartados.
 * Métodos públicos: chamar na thread principal.
 */
object CommCore : WifiDirectController.Listener, PeerConnection.Listener, BluetoothLink.Listener {

    enum class St { IDLE, SEARCHING, CONNECTING, CONNECTED, TRANSMITTING, RECEIVING, LOST, MIC_ERROR, INCOMPATIBLE }
    enum class Mode { WALKIE, CALL }
    enum class Last { NONE, P2P, HOST, JOIN, BT }
    enum class Q { NONE, STABLE, WEAK, RECOVERING, LOST }

    class DevEntry(val label: String, val sub: String, val transport: Transport, val id: String, val p2p: WifiP2pDevice?)
    class LinkInfo(val transport: Transport, val active: Boolean, val rttMs: Int, val lossPct: Int, val score: Int)

    private lateinit var app: Context
    private val handler = Handler(Looper.getMainLooper())
    private var inited = false
    private lateinit var p2p: WifiDirectController
    private lateinit var bt: BluetoothLink
    private val player = AudioPlayer()
    private val conns = CopyOnWriteArrayList<PeerConnection>()
    private val seen = SeenCache(1024)
    private var recorder: AudioRecorder? = null
    private val activeFor = java.util.concurrent.ConcurrentHashMap<Int, PeerConnection>()
    private val votes = HashMap<Int, Int>()

    // ----- estado visível pela interface -----
    var onChange: (() -> Unit)? = null
    var peers: List<WifiP2pDevice> = emptyList(); private set
    private var btDevs: List<BluetoothLink.BtDev> = emptyList()
    val participants = LinkedHashMap<Int, String>()
    val events = ArrayList<String>()
    var state = St.IDLE; private set
    var detail = ""; private set
    var mode = Mode.WALKIE; private set
    var callActive = false; private set
    var banner: String? = null; private set
    var rxName: String? = null; private set
    var reconnecting = false; private set
    var linkReason = ""; private set
    @Volatile var txSince = 0L; private set
    @Volatile var rxSince = 0L; private set
    val waveTx = FloatArray(48)
    val waveRx = FloatArray(48)
    @Volatile private var wTx = 0
    @Volatile private var wRx = 0

    val channelNumber: Int get() = channel
    val p2pSupported: Boolean get() = p2p.supported
    val btSupported: Boolean get() = bt.supported
    val btEnabled: Boolean get() = bt.enabled
    fun btPermitted(): Boolean = bt.permitted()
    fun connected(): Boolean = conns.isNotEmpty() &&
        (state == St.CONNECTED || state == St.TRANSMITTING || state == St.RECEIVING || state == St.MIC_ERROR)
    fun transmitting(): Boolean = txActive
    fun encrypted(): Boolean = key != null

    /** Número de vizinhos distintos (um vizinho com 2 ligações conta uma vez). */
    val peerCount: Int
        get() {
            val ids = HashSet<Int>()
            var unknown = 0
            for (c in conns) if (c.peerId == 0) unknown++ else ids.add(c.peerId)
            return ids.size + unknown
        }

    // ----- internos -----
    private var myId = 0
    private var channel = 1
    private var key: SecretKeySpec? = null
    private var isHost = false
    private var stopped = false
    private var lastMode = Last.NONE
    private var btInitiator = false
    private var lanServer: ServerSocket? = null
    private var searchTick = 0
    private var slowTick = 0
    private var btTries = 0
    private var lastResult = "a iniciar"
    private var retry = 0
    private val failures = java.util.concurrent.ConcurrentHashMap<Transport, Double>()

    @Volatile private var txActive = false
    @Volatile private var txFlags = 0
    private var myTx = 0
    @Volatile private var mySeq = 0
    @Volatile private var rxTx = 0
    @Volatile private var rxSrc = 0
    @Volatile private var rxUrgent = false
    @Volatile private var lastSeq = -1
    @Volatile private var lastAudioAt = 0L

    fun init(ctx: Context) {
        if (inited) return
        inited = true
        app = ctx.applicationContext
        myId = Prefs.nodeId(app)
        stopped = Prefs.stopped(app)
        Prefs.migrate(app)
        loadChannel()
        PhoneNet.start(app)
        player.setVolume(Prefs.voiceVolume(app) / 100f)
        p2p = WifiDirectController(app, this)
        p2p.register()
        bt = BluetoothLink(app, this)
        handler.postDelayed(ticker, 2000)
    }

    private fun log(text: String) {
        val t = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        events.add(0, "$t $text")
        while (events.size > 6) events.removeAt(events.size - 1)
    }

    // =====================================================================
    // Canais e cifra
    // =====================================================================

    private fun loadChannel() {
        channel = Prefs.channel(app).coerceIn(1, 8)
        key = try {
            Crypto.deriveKey(Prefs.code(app, channel), channel)
        } catch (e: Exception) {
            null
        }
    }

    /** Escolhe o canal activo (cada canal tem o seu nome e a sua palavra-passe). */
    fun selectChannel(n: Int) {
        Prefs.setChannel(app, n)
        loadChannel()
        log(Prefs.channelLabel(app, channel))
        updateService()
        changed()
    }

    /** Define, altera ou (com "") remove a palavra-passe de um canal. Remover apaga o segredo; o nome e o resto ficam. */
    fun setChannelCode(n: Int, code: String) {
        Prefs.setCode(app, n, code)
        if (n == channel) loadChannel()
        log(Prefs.channelLabel(app, n) + (if (code.isEmpty()) ": palavra-passe removida" else ": palavra-passe definida"))
        changed()
    }

    fun channelProtected(n: Int): Boolean = Prefs.hasCode(app, n)

    /** Para o LCD/notificação reflectirem imediatamente nomes editados. */
    fun selectChannelRefresh() {
        updateService()
        changed()
    }

    private fun sealWith(type: Int, src: Int, tx: Int, seq: Int, plain: ByteArray): ByteArray {
        val k = key ?: return plain
        return Crypto.seal(k, plain, Crypto.aad(type, channel, src, tx, seq))
    }

    private fun open(p: Packet): ByteArray? {
        val k = key ?: return p.payload
        return Crypto.open(k, p.payload, Crypto.aad(p.type, p.channel, p.src, p.tx, p.seq))
    }

    /** Envia por UMA ligação activa de cada vizinho (nunca o mesmo áudio por todas as ligações). */
    private fun sendAll(type: Int, flags: Int, tx: Int, seq: Int, plain: ByteArray, ttl: Int = Protocol.DEFAULT_TTL) {
        val pk = Packet(type, ttl, flags, channel, myId, tx, seq, sealWith(type, myId, tx, seq, plain))
        for (c in routes(null)) c.send(pk)
    }

    private fun helloSeq(): Int = (SystemClock.elapsedRealtime() and 0x7fffffffL).toInt()

    private fun sendHelloTo(c: PeerConnection, srcId: Int, name: String, ttl: Int) {
        val plain = byteArrayOf(Protocol.VERSION.toByte()) + name.toByteArray(Charsets.UTF_8)
        val seq = helloSeq()
        c.send(Packet(Protocol.T_HELLO, ttl, 0, channel, srcId, 0, seq, sealWith(Protocol.T_HELLO, srcId, 0, seq, plain)))
    }

    // =====================================================================
    // Escolha de ligação (camada híbrida)
    // =====================================================================

    private fun manualTransport(): Transport? = when (Prefs.method(app)) {
        "bt" -> Transport.BLUETOOTH
        "p2p" -> Transport.WIFI_DIRECT
        "lan" -> Transport.HOTSPOT
        else -> null
    }

    /** Pontuação 0..100 a partir de medições reais: latência, jitter, pings perdidos, áudio descartado e falhas recentes. */
    private fun linkScore(c: PeerConnection): Int {
        var s = 100.0
        if (c.rtt < 0) s -= 10 else {
            s -= (c.rtt / 12.0).coerceAtMost(40.0)
            s -= (c.jitter / 8.0).coerceAtMost(15.0)
        }
        s -= c.lossEma * 60.0
        s -= c.dropEma * 30.0
        s -= c.missedStreak * 15.0
        s -= (failures[c.transport] ?: 0.0) * 10.0
        return s.toInt().coerceIn(0, 100)
    }

    private fun groupByPeer(): Map<Int, List<PeerConnection>> {
        val m = LinkedHashMap<Int, ArrayList<PeerConnection>>()
        for (c in conns) if (c.peerId != 0) m.getOrPut(c.peerId) { ArrayList() }.add(c)
        return m
    }

    /** Ligações a usar agora (uma por vizinho). `from` exclui o vizinho de onde veio o pacote. */
    private fun routes(from: PeerConnection?): List<PeerConnection> {
        val out = ArrayList<PeerConnection>()
        for (c in conns) if (c.peerId == 0 && c !== from) out.add(c)
        for ((id, list) in groupByPeer()) {
            if (from != null && from.peerId == id) continue
            val cur = activeFor[id]
            out.add(if (cur != null && conns.contains(cur)) cur else bestOf(list))
        }
        return out
    }

    private fun bestOf(list: List<PeerConnection>): PeerConnection {
        val manual = manualTransport()
        val pool = if (manual != null && list.any { it.transport == manual }) list.filter { it.transport == manual } else list
        return pool.maxByOrNull { linkScore(it) } ?: list[0]
    }

    /** Avalia periodicamente; só muda de ligação com histerese (2 avaliações seguidas) para evitar oscilações. */
    private fun evaluateLinks() {
        for ((id, list) in groupByPeer()) {
            val best = bestOf(list)
            val cur = activeFor[id]
            if (cur == null || !conns.contains(cur)) {
                activeFor[id] = best
                continue
            }
            val curS = linkScore(cur)
            val bestS = linkScore(best)
            val manual = manualTransport()
            val forced = manual != null && best.transport == manual && cur.transport != manual
            val better = best !== cur && bestS > curS && (bestS >= curS + 20 || curS < 40 || forced)
            if (better) {
                val v = (votes[id] ?: 0) + 1
                if (v >= 2) {
                    votes[id] = 0
                    activeFor[id] = best
                    linkReason = cur.transport.label + " " + (if (forced) "não é o método escolhido" else "fraco (" + curS + "/100)") +
                        " → " + best.transport.label
                    log(linkReason)
                } else votes[id] = v
            } else votes[id] = 0
        }
    }

    val activeTransport: Transport?
        get() = routes(null).firstOrNull()?.transport

    fun quality(): Q {
        if (conns.isEmpty()) return if (reconnecting) Q.RECOVERING else if (state == St.LOST) Q.LOST else Q.NONE
        val r = routes(null)
        if (r.isEmpty()) return Q.NONE
        val worst = r.minOf { linkScore(it) }
        return if (worst >= 70) Q.STABLE else Q.WEAK
    }

    fun qualityScore(): Int = if (conns.isEmpty()) 0 else routes(null).minOfOrNull { linkScore(it) } ?: 0

    fun links(): List<LinkInfo> {
        val act = routes(null)
        return conns.map { LinkInfo(it.transport, act.contains(it), it.rtt.toInt(), (it.lossEma * 100).toInt(), linkScore(it)) }
    }

    // =====================================================================
    // Estado / notificação
    // =====================================================================

    private fun changed() {
        handler.post { onChange?.invoke() }
    }

    private fun setState(s: St, d: String = "") {
        state = s
        detail = d
        updateService()
        onChange?.invoke()
    }

    fun notifText(): String {
        val ch = Prefs.channelLabel(app, channel)
        val s = when (state) {
            St.CONNECTED, St.TRANSMITTING, St.RECEIVING, St.MIC_ERROR ->
                "Ligado" + (activeTransport?.let { " (" + it.label + ")" } ?: "") + " · " + peerCount + " dispositivo(s)"
            St.SEARCHING -> "A procurar dispositivos"
            St.CONNECTING -> if (lastMode == Last.HOST || (lastMode == Last.BT && !btInitiator)) "A aguardar dispositivos" else "A estabelecer ligação"
            St.LOST -> if (reconnecting) "Ligação perdida · a reconectar" else "Ligação perdida"
            else -> "Desligado"
        }
        return s + " · " + ch
    }

    private fun updateService() {
        val active = state == St.SEARCHING || state == St.CONNECTING || state == St.CONNECTED ||
            state == St.TRANSMITTING || state == St.RECEIVING || state == St.MIC_ERROR ||
            (state == St.LOST && reconnecting)
        if (Prefs.background(app) && !stopped && active) CommService.start(app, notifText()) else CommService.stop(app)
    }

    fun refreshService() = updateService()

    private fun userStart() {
        stopped = false
        Prefs.setStopped(app, false)
    }

    private fun setBanner(text: String) {
        banner = text
        onChange?.invoke()
        handler.postDelayed({
            if (banner == text) {
                banner = null
                onChange?.invoke()
            }
        }, 6000)
    }

    // =====================================================================
    // Lista de dispositivos (Wi-Fi Direct + Bluetooth)
    // =====================================================================

    fun deviceEntries(): List<DevEntry> {
        val l = ArrayList<DevEntry>()
        for (d in peers) l.add(DevEntry(d.deviceName.ifBlank { d.deviceAddress }, "Wi-Fi Direct", Transport.WIFI_DIRECT, d.deviceAddress, d))
        for (b in btDevs) l.add(DevEntry(b.name, "Bluetooth" + if (b.paired) " · emparelhado" else "", Transport.BLUETOOTH, b.address, null))
        return l
    }

    fun connectEntry(e: DevEntry) {
        if (e.transport == Transport.BLUETOOTH) connectBt(e.id, e.label, false)
        else e.p2p?.let { connectDevice(it) }
    }

    // =====================================================================
    // Pesquisa Wi-Fi Direct
    // =====================================================================

    @Suppress("DEPRECATION")
    private fun wifiOn(): Boolean =
        (app.getSystemService(Context.WIFI_SERVICE) as? WifiManager)?.isWifiEnabled == true

    private fun locationOn(): Boolean {
        val lm = app.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return false
        return LocationManagerCompat.isLocationEnabled(lm)
    }

    fun searchBlockedReason(): String? =
        if (Build.VERSION.SDK_INT < 33 && !locationOn()) app.getString(R.string.err_location) else null

    private fun diag(): String =
        app.getString(R.string.detail_searching) + "\n\nDiagnóstico: Android " + Build.VERSION.RELEASE +
            " · Wi-Fi " + (if (wifiOn()) "ligado" else "DESLIGADO") +
            " · Localização " + (if (locationOn()) "ligada" else "DESLIGADA") +
            " · Encontrados: " + peers.size + " · Pesquisa: " + lastResult

    fun startSearch() {
        userStart()
        lastMode = Last.P2P
        Prefs.setLastMode(app, "p2p")
        closeLan()
        if (!p2p.supported) {
            setState(St.INCOMPATIBLE, app.getString(R.string.err_incompat))
            return
        }
        searchTick = 0
        lastResult = "a iniciar"
        peers = emptyList()
        setState(St.SEARCHING, diag())
        p2p.discover()
    }

    fun connectDevice(d: WifiP2pDevice) {
        userStart()
        lastMode = Last.P2P
        setState(St.CONNECTING, "A ligar a " + d.deviceName + "… No outro telemóvel, puxe a barra de notificações e aceite o convite Wi-Fi Direct.")
        p2p.connect(d)
        handler.removeCallbacks(connectTimeout)
        handler.postDelayed(connectTimeout, 45000)
    }

    private val connectTimeout = Runnable {
        if (state == St.CONNECTING && conns.isEmpty() && lastMode == Last.P2P) {
            p2p.disconnect()
            setState(St.IDLE, app.getString(R.string.err_timeout))
        }
    }

    override fun onP2pState(enabled: Boolean) {
        if (!enabled && conns.isEmpty() && (state == St.IDLE || state == St.SEARCHING) && lastMode == Last.P2P) {
            setState(St.IDLE, app.getString(R.string.wifi_off))
        }
    }

    override fun onPeers(list: List<WifiP2pDevice>) {
        if (conns.isEmpty()) {
            peers = list
            onChange?.invoke()
        }
    }

    override fun onDiscoveryStarted() {
        lastResult = "activa"
        if (state == St.SEARCHING && lastMode == Last.P2P) setState(St.SEARCHING, diag())
    }

    override fun onDiscoveryFailed(reason: Int) {
        lastResult = "erro $reason"
        if (state == St.SEARCHING && reason == WifiP2pManager.BUSY) return
        when (reason) {
            WifiP2pManager.P2P_UNSUPPORTED -> setState(St.INCOMPATIBLE, app.getString(R.string.err_incompat))
            WifiP2pManager.BUSY -> setState(St.IDLE, app.getString(R.string.err_busy))
            else -> setState(St.IDLE, app.getString(R.string.err_generic) + " (código " + reason + ")")
        }
    }

    override fun onConnecting() {}

    override fun onConnectFailed(reason: Int) {
        handler.removeCallbacks(connectTimeout)
        if (conns.isEmpty()) setState(St.IDLE, app.getString(R.string.err_connect) + " (código " + reason + ")")
    }

    override fun onSocketReady(socket: Socket, isOwner: Boolean) {
        handler.removeCallbacks(connectTimeout)
        addConnection(PeerConnection(socket, Transport.WIFI_DIRECT, this), isOwner)
    }

    override fun onSocketFailed() {
        p2p.disconnect()
        if (conns.isEmpty()) setState(St.IDLE, app.getString(R.string.err_socket))
    }

    override fun onGroupLost() {
        val gone = conns.filter { it.transport == Transport.WIFI_DIRECT }
        if (gone.isNotEmpty()) {
            for (c in gone) dropConn(c, app.getString(R.string.msg_lost), false)
        } else if (state == St.CONNECTING && lastMode == Last.P2P) {
            setState(St.IDLE, app.getString(R.string.err_connect))
        }
    }

    override fun onSecurityError() {
        setState(St.IDLE, app.getString(R.string.perm_denied))
    }

    // =====================================================================
    // Bluetooth
    // =====================================================================

    private fun btReady(): Boolean = bt.supported && bt.enabled && bt.permitted()

    /** Escuta ligações e mostra os dispositivos emparelhados + descobertos. */
    fun startBluetooth() {
        userStart()
        lastMode = Last.BT
        Prefs.setLastMode(app, "bt")
        closeLan()
        if (!bt.supported) {
            setState(St.INCOMPATIBLE, app.getString(R.string.bt_incompat))
            return
        }
        if (!bt.enabled) {
            setState(St.IDLE, app.getString(R.string.bt_off))
            return
        }
        btInitiator = false
        bt.startServer()
        bt.refreshBonded()
        bt.startDiscovery()
        setState(St.SEARCHING, app.getString(R.string.bt_hint))
    }

    fun connectBt(address: String, name: String, auto: Boolean) {
        if (!auto) userStart()
        if (!auto) {
            lastMode = Last.BT
            Prefs.setLastMode(app, "bt")
        }
        btInitiator = true
        Prefs.setBt(app, address, name)
        if (conns.isEmpty()) setState(St.CONNECTING, "A ligar por Bluetooth a $name…")
        bt.startServer()
        bt.connect(address)
    }

    override fun onBtSocket(s: BluetoothSocket, incoming: Boolean) {
        try {
            val d = s.remoteDevice
            if (d != null) Prefs.setBt(app, d.address, Prefs.btName(app).ifEmpty { d.address })
        } catch (_: Exception) {
        }
        btTries = 0
        addConnection(PeerConnection(s, s.inputStream, s.outputStream, Transport.BLUETOOTH, this), incoming)
    }

    override fun onBtConnectFailed(msg: String) {
        failures[Transport.BLUETOOTH] = (failures[Transport.BLUETOOTH] ?: 0.0) + 0.5
        if (conns.isEmpty()) {
            if (reconnecting) scheduleReconnect(app.getString(R.string.bt_fail))
            else setState(St.IDLE, app.getString(R.string.bt_fail) + " (" + msg + ")")
        }
    }

    override fun onBtDevices(list: List<BluetoothLink.BtDev>) {
        btDevs = list
        onChange?.invoke()
    }

    // =====================================================================
    // Modo hotspot / rede local
    // =====================================================================

    private fun closeLan() {
        try {
            lanServer?.close()
        } catch (_: Exception) {
        }
        lanServer = null
    }

    fun startHost(auto: Boolean = false) {
        if (!auto) userStart()
        lastMode = Last.HOST
        Prefs.setLastMode(app, "host")
        closeLan()
        if (conns.isEmpty()) setState(St.CONNECTING, app.getString(R.string.detail_host))
        Thread({
            var created: ServerSocket? = null
            try {
                val ss = ServerSocket()
                created = ss
                ss.reuseAddress = true
                ss.bind(InetSocketAddress(Protocol.PORT))
                handler.post {
                    if (stopped) {
                        ss.close()
                    } else {
                        lanServer = ss
                    }
                }
                while (!ss.isClosed) {
                    val s = ss.accept()
                    s.tcpNoDelay = true
                    handler.post {
                        if (lanServer === ss) {
                            addConnection(PeerConnection(s, Transport.HOTSPOT, this), true)
                        } else {
                            s.close()
                        }
                    }
                }
            } catch (e: Exception) {
                val mine = created
                handler.post {
                    if (mine != null && lanServer === mine) {
                        lanServer = null
                        if (conns.isEmpty()) setState(St.IDLE, app.getString(R.string.err_lan))
                    }
                }
            }
        }, "lan-host").start()
    }

    fun startJoin(auto: Boolean = false) {
        if (!auto) userStart()
        lastMode = Last.JOIN
        Prefs.setLastMode(app, "join")
        closeLan()
        val host = gatewayIp()
        if (host == null) {
            if (auto) scheduleReconnect(app.getString(R.string.err_lan_nowifi))
            else setState(St.IDLE, app.getString(R.string.err_lan_nowifi))
            return
        }
        if (conns.isEmpty()) setState(St.CONNECTING, "A ligar a $host…")
        Thread({
            var s: Socket? = null
            var tries = 0
            while (s == null && tries < 10) {
                tries++
                val c = Socket()
                try {
                    wifiNetwork()?.bindSocket(c)
                    c.connect(InetSocketAddress(host, Protocol.PORT), 3000)
                    s = c
                } catch (e: Exception) {
                    try {
                        c.close()
                    } catch (_: Exception) {
                    }
                    Thread.sleep(800)
                }
            }
            val sock = s
            handler.post {
                if (sock != null && !stopped) {
                    sock.tcpNoDelay = true
                    addConnection(PeerConnection(sock, Transport.HOTSPOT, this), false)
                } else {
                    try {
                        sock?.close()
                    } catch (_: Exception) {
                    }
                    if (conns.isEmpty() && state == St.CONNECTING) {
                        if (auto) scheduleReconnect(app.getString(R.string.err_lan))
                        else setState(St.IDLE, app.getString(R.string.err_lan))
                    }
                }
            }
        }, "lan-join").start()
    }

    @Suppress("DEPRECATION")
    private fun gatewayIp(): String? {
        val wm = app.getSystemService(Context.WIFI_SERVICE) as? WifiManager ?: return null
        val g = wm.dhcpInfo?.gateway ?: 0
        if (g == 0) return null
        return "" + (g and 0xff) + "." + ((g shr 8) and 0xff) + "." + ((g shr 16) and 0xff) + "." + ((g shr 24) and 0xff)
    }

    @Suppress("DEPRECATION")
    private fun wifiNetwork(): Network? {
        val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return null
        return cm.allNetworks.firstOrNull {
            cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        }
    }

    // =====================================================================
    // Ligações
    // =====================================================================

    private fun addConnection(c: PeerConnection, owner: Boolean) {
        conns.add(c)
        if (conns.size == 1) {
            isHost = owner
            player.start(callActive)
        }
        c.start()
        retry = 0
        reconnecting = false
        handler.removeCallbacks(reconnectRunnable)
        log("Ligado: " + c.transport.label)
        sendHelloTo(c, myId, Build.MODEL, Protocol.DEFAULT_TTL)
        if (state != St.TRANSMITTING && state != St.RECEIVING) setState(St.CONNECTED, "") else changed()
    }

    private fun dropConn(c: PeerConnection, msg: String, intentional: Boolean) {
        val had = conns.remove(c)
        c.close("", false)
        if (!had) return
        failures[c.transport] = (failures[c.transport] ?: 0.0) + (if (intentional) 0.0 else 1.0)
        val others = if (c.peerId != 0) conns.filter { it.peerId == c.peerId } else emptyList()
        if (activeFor[c.peerId] === c) activeFor.remove(c.peerId)
        if (others.isNotEmpty()) {
            linkReason = c.transport.label + " perdido → " + bestOf(others).transport.label
            log(linkReason)
        } else if (c.peerId != 0) participants.remove(c.peerId)
        if (conns.isEmpty()) onAllLost(msg, intentional) else changed()
    }

    override fun onClosed(from: PeerConnection, reason: String) {
        handler.post { if (conns.contains(from)) dropConn(from, app.getString(R.string.msg_lost), false) }
    }

    private fun onAllLost(msg: String, intentional: Boolean) {
        endLocalActivity()
        participants.clear()
        activeFor.clear()
        player.stop()
        log(msg)
        when {
            lastMode == Last.HOST && lanServer != null -> setState(St.CONNECTING, app.getString(R.string.detail_host))
            lastMode == Last.BT && !btInitiator && !intentional -> {
                bt.startServer()
                setState(St.CONNECTING, app.getString(R.string.bt_wait))
            }
            intentional -> {
                p2p.disconnect()
                setState(St.IDLE, msg)
            }
            (lastMode == Last.JOIN || lastMode == Last.HOST || lastMode == Last.BT) && Prefs.reconnect(app) -> scheduleReconnect(msg)
            else -> {
                p2p.disconnect()
                setState(St.LOST, msg)
            }
        }
    }

    private fun endLocalActivity() {
        if (txActive) {
            txActive = false
            recorder?.stop()
            recorder = null
        }
        if (callActive) {
            callActive = false
            setCallAudio(false)
        }
        rxTx = 0
        rxUrgent = false
        rxName = null
        txSince = 0
        rxSince = 0
    }

    // ----- reconexão controlada -----

    private val reconnectRunnable = Runnable {
        if (reconnecting && !stopped) {
            when (lastMode) {
                Last.HOST -> startHost(true)
                Last.JOIN -> startJoin(true)
                Last.BT -> {
                    val a = Prefs.btAddress(app)
                    if (a.isNotEmpty()) connectBt(a, Prefs.btName(app), true) else reconnecting = false
                }
                else -> reconnecting = false
            }
        }
    }

    private fun scheduleReconnect(msg: String) {
        if (stopped) return
        if (!Prefs.reconnect(app) || retry >= 12) {
            reconnecting = false
            setState(St.LOST, msg)
            return
        }
        retry++
        reconnecting = true
        setState(St.LOST, "$msg A tentar de novo ($retry/12)…")
        handler.removeCallbacks(reconnectRunnable)
        handler.postDelayed(reconnectRunnable, 5000)
    }

    fun resumeAfterBoot() {
        if (stopped || !Prefs.autostart(app)) return
        when (Prefs.lastMode(app)) {
            "host" -> startHost(true)
            "join" -> startJoin(true)
            "bt" -> {
                val a = Prefs.btAddress(app)
                if (a.isNotEmpty() && btReady()) connectBt(a, Prefs.btName(app), true) else setState(St.IDLE, app.getString(R.string.boot_need_user))
            }
            else -> setState(St.IDLE, app.getString(R.string.boot_need_user))
        }
    }

    /** Botão verde: liga com o último método usado, ou inicia a chamada se já houver ligação. */
    fun quickConnect(): Boolean {
        if (connected()) {
            if (mode == Mode.CALL && !callActive) {
                startCall()
                return true
            }
            return false
        }
        when (Prefs.lastMode(app)) {
            "host" -> startHost()
            "join" -> startJoin()
            "bt" -> {
                val a = Prefs.btAddress(app)
                if (a.isEmpty()) return false
                connectBt(a, Prefs.btName(app), false)
            }
            "p2p" -> startSearch()
            else -> return false
        }
        return true
    }

    /** PARAR SERVIÇO / botão vermelho. */
    fun stopAll(byUser: Boolean) {
        if (byUser) {
            stopped = true
            Prefs.setStopped(app, true)
        }
        reconnecting = false
        retry = 0
        handler.removeCallbacks(reconnectRunnable)
        handler.removeCallbacks(connectTimeout)
        endLocalActivity()
        for (c in conns) {
            val seq = helloSeq()
            c.sendByeAndClose(Packet(Protocol.T_BYE, 1, 0, channel, myId, 0, seq, sealWith(Protocol.T_BYE, myId, 0, seq, ByteArray(0))))
        }
        conns.clear()
        participants.clear()
        activeFor.clear()
        closeLan()
        bt.release()
        player.stop()
        p2p.disconnect()
        peers = emptyList()
        btDevs = emptyList()
        banner = null
        log("Serviço parado")
        setState(St.IDLE, app.getString(R.string.msg_stopped))
        CommService.stop(app)
    }

    // =====================================================================
    // Recepção (threads de leitura)
    // =====================================================================

    override fun onPacket(from: PeerConnection, p: Packet) {
        from.lastRx = SystemClock.elapsedRealtime()
        if (p.type == Protocol.T_PING) {
            from.send(Packet(Protocol.T_PONG, 1, 0, channel, myId, 0, 0, p.payload))
            return
        }
        if (p.type == Protocol.T_PONG) {
            if (p.payload.size == 8) {
                val sent = java.nio.ByteBuffer.wrap(p.payload).getLong()
                val r = (SystemClock.elapsedRealtimeNanos() - sent) / 1_000_000.0
                if (r >= 0 && r < 60000) {
                    val prev = from.rtt
                    from.rtt = if (prev < 0) r else prev * 0.7 + r * 0.3
                    if (prev >= 0) from.jitter = from.jitter * 0.7 + Math.abs(r - prev) * 0.3
                }
                from.pingOut = false
                from.missedStreak = 0
            }
            return
        }
        if (p.channel != channel || p.src == myId) return
        if (!seen.firstTime(p.src, p.tx, p.seq, p.type)) return
        val plain = open(p)
        if (plain == null) {
            if (p.type == Protocol.T_HELLO) handler.post { if (conns.contains(from)) unauthorized(from) }
            return
        }
        from.authorized = true
        relay(from, p)
        when (p.type) {
            Protocol.T_HELLO -> onHello(from, p, plain)
            Protocol.T_TX_START -> onTxStart(p)
            Protocol.T_AUDIO -> {
                if (p.src == rxSrc && p.tx == rxTx && p.seq > lastSeq) {
                    lastSeq = p.seq
                    lastAudioAt = SystemClock.elapsedRealtime()
                    waveRx[wRx % waveRx.size] = pcmLevel(plain)
                    wRx++
                    player.enqueue(plain)
                }
            }
            Protocol.T_TX_END -> {
                if (p.src == rxSrc && p.tx == rxTx) {
                    rxTx = 0
                    rxUrgent = false
                    handler.post {
                        rxName = null
                        rxSince = 0
                        if (state == St.RECEIVING) setState(St.CONNECTED, "") else changed()
                    }
                }
            }
            Protocol.T_BYE -> handler.post {
                if (conns.contains(from)) dropConn(from, app.getString(R.string.msg_peer_bye), true)
            }
        }
    }

    private fun unauthorized(c: PeerConnection) {
        setBanner(app.getString(R.string.banner_unauthorized))
        dropConn(c, app.getString(R.string.banner_unauthorized), true)
    }

    /** Repetidor: reenvia (sem descodificar) com TTL-1, só pacotes autenticados e novos, por uma ligação por vizinho. */
    private fun relay(from: PeerConnection, p: Packet) {
        if (!Prefs.relay(app) || p.ttl <= 1 || p.type == Protocol.T_BYE) return
        val targets = routes(from)
        if (targets.isEmpty()) return
        val q = Packet(p.type, p.ttl - 1, p.flags, p.channel, p.src, p.tx, p.seq, p.payload)
        for (c in targets) c.send(q)
    }

    private fun onHello(from: PeerConnection, p: Packet, plain: ByteArray) {
        val name = if (plain.size > 1) String(plain, 1, plain.size - 1, Charsets.UTF_8) else "Dispositivo"
        val src = p.src
        if (p.ttl == Protocol.DEFAULT_TTL) from.peerId = src // vizinho directo
        handler.post {
            val isNew = !participants.containsKey(src)
            participants[src] = name
            if (isNew && isHost && p.ttl == Protocol.DEFAULT_TTL && conns.contains(from)) {
                for ((id, n) in participants) if (id != src) sendHelloTo(from, id, n, 1)
            }
            onChange?.invoke()
        }
    }

    private fun onTxStart(p: Packet) {
        val urgent = (p.flags and Protocol.F_URGENT) != 0
        val peerCall = (p.flags and Protocol.F_CALL) != 0
        if (rxTx != 0 && p.src != rxSrc && !urgent) return
        if (txActive && !callActive) {
            if (urgent) handler.post { stopTransmit(); setBanner(app.getString(R.string.banner_interrupted)) }
            else if (isHost) return
            else handler.post { stopTransmit() }
        }
        val isNew = p.tx != rxTx || p.src != rxSrc
        rxTx = p.tx
        rxSrc = p.src
        rxUrgent = urgent
        lastSeq = -1
        lastAudioAt = SystemClock.elapsedRealtime()
        player.flush()
        if (urgent) player.playAlert() else if (Prefs.beep(app)) player.playBeep()
        if (isNew) vibrate(if (urgent) 2 else 1)
        handler.post {
            if (conns.isEmpty()) return@post
            rxName = participants[p.src] ?: "Dispositivo"
            rxSince = SystemClock.elapsedRealtime()
            if (isNew) log((if (urgent) "URGÊNCIA de " else "Novo áudio de ") + rxName)
            if (urgent) setBanner(app.getString(R.string.banner_urgent_from) + " " + rxName)
            if (!callActive || !peerCall) {
                if (!txActive) setState(St.RECEIVING, "") else changed()
            } else changed()
        }
    }

    // =====================================================================
    // Transmissão
    // =====================================================================

    fun setMode(m: Mode) {
        if (callActive) return
        mode = m
        changed()
    }

    fun pttDown(urgent: Boolean) {
        if (!connected() || txActive) return
        if (mode == Mode.CALL && !urgent) return
        if (rxTx != 0 && !urgent) return
        startTransmit(urgent, false)
    }

    fun pttUp() {
        if (callActive) return
        stopTransmit()
    }

    fun startCall() {
        if (!connected() || mode != Mode.CALL || callActive || txActive) return
        callActive = true
        setCallAudio(true)
        player.stop()
        player.start(true)
        startTransmit(false, true)
    }

    fun endCall() {
        if (!callActive) return
        stopTransmit()
        callActive = false
        setCallAudio(false)
        player.stop()
        player.start(false)
        if (conns.isNotEmpty()) setState(St.CONNECTED, "")
    }

    private fun startTransmit(urgent: Boolean, call: Boolean) {
        val flags = (if (urgent) Protocol.F_URGENT else 0) or (if (call) Protocol.F_CALL else 0)
        myTx = Random.nextInt(1, Int.MAX_VALUE)
        mySeq = 0
        txFlags = flags
        if (urgent && rxTx != 0) {
            rxTx = 0
            rxUrgent = false
            rxName = null
            rxSince = 0
            player.flush()
        }
        val id = myTx
        sendAll(Protocol.T_TX_START, flags, id, 0, ByteArray(0))
        val rec = AudioRecorder(
            { f ->
                if (txActive && id == myTx) {
                    waveTx[wTx % waveTx.size] = pcmLevel(f)
                    wTx++
                    sendAll(Protocol.T_AUDIO, flags, id, ++mySeq, f)
                }
            },
            { handler.post { micError() } }
        )
        if (!rec.start()) {
            sendAll(Protocol.T_TX_END, flags, id, 1, ByteArray(0))
            callActive = false
            micError()
            return
        }
        recorder = rec
        txActive = true
        txSince = SystemClock.elapsedRealtime()
        vibrate(if (urgent) 2 else 0)
        if (urgent) setBanner(app.getString(R.string.banner_urgent_sent))
        setState(St.TRANSMITTING, "")
    }

    fun stopTransmit() {
        if (!txActive) return
        txActive = false
        txSince = 0
        recorder?.stop()
        recorder = null
        sendAll(Protocol.T_TX_END, txFlags, myTx, ++mySeq, ByteArray(0))
        if (state == St.TRANSMITTING && !callActive) setState(St.CONNECTED, "")
    }

    private fun micError() {
        txActive = false
        txSince = 0
        recorder?.stop()
        recorder = null
        if (callActive) {
            callActive = false
            setCallAudio(false)
        }
        if (conns.isNotEmpty()) setState(St.MIC_ERROR, app.getString(R.string.err_mic))
    }

    @Suppress("DEPRECATION")
    private fun setCallAudio(on: Boolean) {
        try {
            val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.mode = if (on) AudioManager.MODE_IN_COMMUNICATION else AudioManager.MODE_NORMAL
            am.isSpeakerphoneOn = on
        } catch (_: Exception) {
        }
    }

    fun setVolume(v: Float) {
        player.setVolume(v)
        Prefs.setVoiceVolume(app, (v * 100).toInt())
    }

    private fun vibrator(): Vibrator? =
        if (Build.VERSION.SDK_INT >= 31) (app.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        else @Suppress("DEPRECATION") (app.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator)

    /**
     * kind: 0 = início da minha transmissão (uso TOUCH), 1 = nova transmissão recebida, 2 = urgência, 3 = teste.
     * Uma só chamada por evento (nunca por pacote). Usa o uso de áudio adequado: as vibrações de "notificação" são
     * silenciadas por muitas definições do telemóvel, por isso os eventos de rádio usam TOUCH/ALARM.
     * Devolve um texto de diagnóstico (usado em "Testar vibração").
     */
    @Suppress("DEPRECATION")
    fun vibrate(kind: Int): String {
        if (kind != 3 && !Prefs.vibration(app)) return "Vibração desligada nas definições"
        val v = vibrator() ?: return "Este telemóvel não expõe vibrador"
        if (!v.hasVibrator()) return "Este telemóvel não tem vibrador"
        val effect = if (kind == 2) VibrationEffect.createWaveform(longArrayOf(0, 120, 70, 120, 70, 120), -1)
        else VibrationEffect.createOneShot(if (kind == 3) 120 else 60, VibrationEffect.DEFAULT_AMPLITUDE)
        val usage = if (kind == 0) AudioAttributes.USAGE_TOUCH else AudioAttributes.USAGE_ALARM
        return try {
            v.vibrate(effect, AudioAttributes.Builder().setUsage(usage).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            "Vibração enviada" + (if (v.hasAmplitudeControl()) "" else " (sem controlo de intensidade)")
        } catch (e: Exception) {
            try {
                v.vibrate(effect)
                "Vibração enviada (modo simples)"
            } catch (e2: Exception) {
                "Falha ao vibrar: " + (e2.message ?: "erro")
            }
        }
    }

    fun testVibration(): String = vibrate(3)

    // =====================================================================
    // Relógio de manutenção (2 s): pings/medições, avaliação de ligações, standby Bluetooth
    // =====================================================================

    private val ticker = object : Runnable {
        override fun run() {
            val now = SystemClock.elapsedRealtime()
            if (rxTx != 0 && now - lastAudioAt > 3000) {
                rxTx = 0
                rxUrgent = false
                rxName = null
                rxSince = 0
                if (state == St.RECEIVING) setState(St.CONNECTED, "") else changed()
            }
            for (f in failures.keys.toList()) failures[f] = (failures[f] ?: 0.0) * 0.97
            for (c in conns) {
                // medições: um ping sem resposta antes do seguinte conta como perda
                if (c.pingOut) {
                    c.lossEma = c.lossEma * 0.8 + 0.2
                    c.missedStreak++
                } else c.lossEma *= 0.8
                val d = c.dropped
                c.dropEma = c.dropEma * 0.7 + (if (d > c.lastDropped) 0.3 else 0.0)
                c.lastDropped = d
                c.pingOut = true
                c.send(Packet(Protocol.T_PING, 1, 0, channel, myId, 0, 0, java.nio.ByteBuffer.allocate(8).putLong(SystemClock.elapsedRealtimeNanos()).array()))
                if (!c.authorized && now - c.created > 10000) {
                    unauthorized(c)
                } else if (now - c.lastRx > 15000) {
                    c.close("Sem resposta do outro dispositivo", true)
                }
            }
            evaluateLinks()
            if (state == St.SEARCHING && lastMode == Last.P2P) {
                searchTick++
                p2p.refreshPeers()
                if (searchTick % 4 == 0) p2p.discover()
                setState(St.SEARCHING, diag())
            }
            slowTick++
            if (slowTick % 8 == 0 && conns.isNotEmpty()) hybridMaintenance()
            if (conns.isNotEmpty()) onChange?.invoke()
            handler.postDelayed(this, 2000)
        }
    }

    /** Camada híbrida: mantém o Bluetooth como ligação em espera quando o método permite (sem insistir: máx. 5 tentativas). */
    private fun hybridMaintenance() {
        val m = Prefs.method(app)
        if (m != "auto" && m != "bt") return
        if (!btReady()) return
        bt.startServer()
        val a = Prefs.btAddress(app)
        if (!isHost && a.isNotEmpty() && btTries < 5 && conns.none { it.transport == Transport.BLUETOOTH }) {
            btTries++
            btInitiator = true
            bt.connect(a)
        }
    }
}
