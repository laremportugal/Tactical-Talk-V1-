package com.tacticaltalk.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Após reiniciar (e o utilizador desbloquear o telefone), tenta retomar o serviço se o
 * Arranque automático estiver activo e o utilizador não tiver carregado em PARAR SERVIÇO.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (!Prefs.autostart(context) || Prefs.stopped(context)) return
        CommCore.init(context)
        CommCore.resumeAfterBoot()
    }
}
