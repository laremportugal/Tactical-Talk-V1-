package com.tacticaltalk.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.telephony.PhoneStateListener
import android.telephony.SignalStrength
import android.telephony.TelephonyCallback
import android.telephony.TelephonyDisplayInfo
import android.telephony.TelephonyManager
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat

/**
 * Estado REAL da rede móvel do telefone (independente da ligação entre rádios TacticalTalk).
 * - Existência de rede móvel: ConnectivityManager (sem permissões perigosas).
 * - Nível de sinal (0..4): callback de telefonia (sem inventar valores; -1 se indisponível).
 * - Geração (2G/3G/4G/5G): só com a permissão READ_PHONE_STATE, pedida apenas se o utilizador activar
 *   "Tipo de rede móvel" nas definições. Sem ela mostra "—".
 * - Frequência/banda exacta: não é fornecida por APIs sem permissões de localização/operador → "indisponível".
 */
object PhoneNet {
    var label = "—"; private set        // 2G, 3G, 4G, 4G+, 5G ou —
    var level = -1; private set         // 0..4, -1 = desconhecido
    var detail = "indisponível"; private set
    var cellular = false; private set   // há rede móvel disponível (ConnectivityManager)

    private lateinit var app: Context
    private var started = false
    private var netCb: ConnectivityManager.NetworkCallback? = null
    private var sigCb: Any? = null
    private var dispCb: Any? = null
    private var legacy: PhoneStateListener? = null
    private var listeners = 0

    private fun hasPhonePerm() =
        ContextCompat.checkSelfPermission(app, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED

    val typeEnabled: Boolean get() = Prefs.mobileInfo(app) && hasPhonePerm()

    fun start(ctx: Context) {
        app = ctx.applicationContext
        if (started) return
        started = true
        startConnectivity()
        refresh()
    }

    private fun startConnectivity() {
        try {
            val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    cellular = true
                }

                override fun onLost(network: Network) {
                    cellular = false
                    label = "—"
                }
            }
            cm.registerNetworkCallback(NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR).build(), cb)
            netCb = cb
        } catch (_: Exception) {
        }
    }

    /** (Re)liga os callbacks de telefonia; chamar depois de a permissão ser concedida/retirada. */
    fun refresh() {
        stopTelephony()
        val tm = app.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager ?: return
        val perm = typeEnabled
        if (!perm) {
            label = "—"
            detail = if (Build.VERSION.SDK_INT >= 30) "tipo de rede: active em Definições (pede permissão do telefone)" else "indisponível"
        }
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                val s = SigCb()
                tm.registerTelephonyCallback(app.mainExecutor, s)
                sigCb = s
                if (perm) {
                    val d = DispCb(tm)
                    tm.registerTelephonyCallback(app.mainExecutor, d)
                    dispCb = d
                }
            } else {
                @Suppress("DEPRECATION")
                val l = object : PhoneStateListener() {
                    @Deprecated("API antiga")
                    override fun onSignalStrengthsChanged(signalStrength: SignalStrength) {
                        level = signalStrength.level
                        if (perm || Build.VERSION.SDK_INT < 30) applyType(tm.dataNetworkType, 0)
                    }
                }
                @Suppress("DEPRECATION")
                tm.listen(l, PhoneStateListener.LISTEN_SIGNAL_STRENGTHS)
                legacy = l
            }
            if (perm || (Build.VERSION.SDK_INT < 30 && Build.VERSION.SDK_INT >= 24)) {
                try {
                    applyType(tm.dataNetworkType, 0)
                } catch (_: SecurityException) {
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun stopTelephony() {
        try {
            val tm = app.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager ?: return
            if (Build.VERSION.SDK_INT >= 31) {
                (sigCb as? TelephonyCallback)?.let { tm.unregisterTelephonyCallback(it) }
                (dispCb as? TelephonyCallback)?.let { tm.unregisterTelephonyCallback(it) }
            } else {
                @Suppress("DEPRECATION")
                legacy?.let { tm.listen(it, PhoneStateListener.LISTEN_NONE) }
            }
        } catch (_: Exception) {
        }
        sigCb = null
        dispCb = null
        legacy = null
    }

    /** Converte o tipo de rede do Android para o que o utilizador reconhece. `override` = TelephonyDisplayInfo.overrideNetworkType. */
    internal fun applyType(type: Int, override: Int) {
        // override: 3 = NR NSA, 4 = NR NSA mmWave, 5 = NR avançado (ícone 5G do operador sobre LTE)
        val nrOverride = override == 3 || override == 4 || override == 5
        val (l, d) = when {
            type == 20 -> Pair("5G", "NR (5G autónomo)")
            nrOverride -> Pair("5G", "LTE + 5G NSA")
            type == 13 -> Pair("4G", "LTE")
            type == 19 -> Pair("4G+", "LTE-CA")
            type in intArrayOf(3, 8, 9, 10, 15, 17) -> Pair("3G", "UMTS/HSPA")
            type in intArrayOf(1, 2, 4, 7, 11, 16) -> Pair("2G", "GSM/EDGE")
            type == 18 -> Pair("—", "IWLAN")
            else -> Pair("—", "desconhecido")
        }
        label = l
        detail = d
    }

    @RequiresApi(31)
    private class SigCb : TelephonyCallback(), TelephonyCallback.SignalStrengthsListener {
        override fun onSignalStrengthsChanged(signalStrength: SignalStrength) {
            level = signalStrength.level
        }
    }

    @RequiresApi(31)
    private class DispCb(private val tm: TelephonyManager) : TelephonyCallback(), TelephonyCallback.DisplayInfoListener {
        override fun onDisplayInfoChanged(telephonyDisplayInfo: TelephonyDisplayInfo) {
            applyType(telephonyDisplayInfo.networkType, telephonyDisplayInfo.overrideNetworkType)
        }
    }

    /** Linha curta para o ecrã: "4G · sinal 3/4". */
    fun summary(): String {
        if (!cellular && level < 0) return "Sem rede móvel"
        val sig = if (level >= 0) " · sinal $level/4" else ""
        return (if (label == "—") "Móvel (tipo n/d)" else label) + sig
    }

    fun frequency(): String = "Frequência: indisponível (requer APIs de operador/localização)"
}
