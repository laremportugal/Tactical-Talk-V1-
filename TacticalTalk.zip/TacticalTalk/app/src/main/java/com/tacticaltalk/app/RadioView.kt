package com.tacticaltalk.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.text.TextPaint
import android.text.TextUtils
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.floor
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Rádio desenhado em código (sem imagem de fundo): ocupa TODO o ecrã e adapta-se à proporção do telefone.
 * As áreas de toque são exactamente os rectângulos desenhados. O LCD mostra dados reais do CommCore.
 */
class RadioView(ctx: Context) : View(ctx) {

    lateinit var ctl: RadioController

    private class KeyBox(val key: Key, val r: RectF, val a: String, val b: String)

    private val keys = ArrayList<KeyBox>()
    private val soft = Array(3) { RectF() }
    private val bezel = RectF()
    private val lcd = RectF()
    private val ptt = RectF()
    private val sos = RectF()
    private val antenna = RectF()
    private val neck = RectF()
    private val brand = RectF()
    private val slot1 = RectF()
    private val slot2 = RectF()
    private var knobX = 0f
    private var knobY = 0f
    private var knobR = 0f
    private var shoulder = 0f
    private var texture: Bitmap? = null

    private val pressed = HashSet<String>()
    private val active = HashMap<Int, String>()
    private var knobLast = 0f

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val path = Path()

    private val cBlue1 = Color.parseColor("#0E3A8C")
    private val cBlue2 = Color.parseColor("#061A52")
    private val cAccent = Color.parseColor("#2F6BEA")
    private val cAmber = Color.parseColor("#F2A83B")
    private val cGreen = Color.parseColor("#3DDC84")
    private val cRed = Color.parseColor("#E5534B")
    private val cMuted = Color.parseColor("#9DB4E8")

    // ------------------------------------------------------------------ layout

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val W = w.toFloat()
        val H = h.toFloat()
        keys.clear()

        val m = W * 0.07f
        val gap = W * 0.028f
        val bottomPad = H * 0.016f
        val keyW = (W - 2 * m - 2 * gap) / 3f
        val lowerH = H * 0.46f
        val rowH = (lowerH - bottomPad - 5 * gap) / 6f
        val lowerTop = H - bottomPad - 6 * rowH - 5 * gap
        fun rowTop(i: Int) = lowerTop + i * (rowH + gap)
        val col = floatArrayOf(m, m + keyW + gap, m + 2 * (keyW + gap))

        keys.add(KeyBox(Key.MENU, RectF(col[0], rowTop(0), col[0] + keyW, rowTop(0) + rowH), "MENU", ""))
        keys.add(KeyBox(Key.GREEN, RectF(col[0], rowTop(1), col[0] + keyW, rowTop(1) + rowH), "", ""))
        keys.add(KeyBox(Key.BACK, RectF(col[2], rowTop(0), col[2] + keyW, rowTop(0) + rowH), "", ""))
        keys.add(KeyBox(Key.RED, RectF(col[2], rowTop(1), col[2] + keyW, rowTop(1) + rowH), "", ""))
        val padL = col[1]
        val padR = col[1] + keyW
        val padT = rowTop(0)
        val padB = rowTop(1) + rowH
        val midY = (padT + padB) / 2f
        keys.add(KeyBox(Key.UP, RectF(padL, padT, padR, midY), "", ""))
        keys.add(KeyBox(Key.DOWN, RectF(padL, midY, padR, padB), "", ""))
        val digits = arrayOf(
            arrayOf(Key.N1, "1", "..,?"), arrayOf(Key.N2, "2", "ABC"), arrayOf(Key.N3, "3", "DEF"),
            arrayOf(Key.N4, "4", "GHI"), arrayOf(Key.N5, "5", "JKL"), arrayOf(Key.N6, "6", "MNO"),
            arrayOf(Key.N7, "7", "PQRS"), arrayOf(Key.N8, "8", "TUV"), arrayOf(Key.N9, "9", "WXYZ"),
            arrayOf(Key.STAR, "*", ""), arrayOf(Key.N0, "0", ""), arrayOf(Key.HASH, "#", "")
        )
        for (i in 0 until 12) {
            val r = i / 3
            val c = i % 3
            val d = digits[i]
            keys.add(KeyBox(d[0] as Key, RectF(col[c], rowTop(2 + r), col[c] + keyW, rowTop(2 + r) + rowH), d[1] as String, d[2] as String))
        }

        // LCD
        val above = lowerTop - H * 0.012f
        val bezelH = min(W * 0.86f, above * 0.50f)
        val bezelW = W * 0.74f
        bezel.set((W - bezelW) / 2f, above - bezelH, (W + bezelW) / 2f, above)
        val inset = bezelW * 0.035f
        lcd.set(bezel.left + inset, bezel.top + inset, bezel.right - inset, bezel.bottom - inset)
        val softTop = lcd.bottom - lcd.height() * 0.19f
        val sw = lcd.width() / 3f
        for (i in 0 until 3) soft[i].set(lcd.left + i * sw, softTop, lcd.left + (i + 1) * sw, lcd.bottom)

        // grelha, marca, ombros
        val slotH = W * 0.055f
        slot2.set(W * 0.12f, bezel.top - H * 0.016f - slotH, W * 0.88f, bezel.top - H * 0.016f)
        slot1.set(W * 0.12f, slot2.top - slotH * 0.45f - slotH, W * 0.88f, slot2.top - slotH * 0.45f)
        val brandH = W * 0.075f
        brand.set(W * 0.22f, slot1.top - H * 0.014f - brandH, W * 0.78f, slot1.top - H * 0.014f)
        shoulder = max(brand.top - H * 0.028f, H * 0.12f)
        neck.set(W * 0.13f, -H * 0.05f, W * 0.87f, shoulder + H * 0.02f)
        antenna.set(W * 0.27f, -H * 0.05f, W * 0.39f, shoulder + H * 0.01f)
        knobR = W * 0.085f
        knobX = W * 0.70f
        knobY = max(shoulder - knobR * 0.6f, knobR * 1.2f)

        // botões laterais (PTT à esquerda, URGÊNCIA à direita), junto ao LCD
        // maiores que antes e sem tocar no LCD (o LCD começa em 0,13 W; o botão acaba em 0,115 W)
        val sideW = W * 0.105f
        ptt.set(W * 0.01f, bezel.top + bezel.height() * 0.03f, W * 0.01f + sideW, bezel.top + bezel.height() * 0.88f)
        sos.set(W - W * 0.01f - sideW, bezel.top + bezel.height() * 0.10f, W - W * 0.01f, bezel.top + bezel.height() * 0.64f)

        texture = try {
            val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val cv = Canvas(b)
            val rnd = Random(7)
            val tpnt = Paint()
            repeat((w * h / 900).coerceAtMost(4000)) {
                tpnt.color = if (rnd.nextBoolean()) Color.argb(40, 255, 255, 255) else Color.argb(60, 0, 0, 0)
                cv.drawCircle(rnd.nextFloat() * w, rnd.nextFloat() * h, 1.1f, tpnt)
            }
            b
        } catch (e: Throwable) {
            null
        }
    }

    // ------------------------------------------------------------------ desenho

    override fun onDraw(c: Canvas) {
        val W = width.toFloat()
        val H = height.toFloat()
        // corpo
        p.shader = LinearGradient(0f, 0f, 0f, H, Color.parseColor("#1A1C1E"), Color.parseColor("#0B0C0D"), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, W, H, p)
        p.shader = null
        texture?.let { c.drawBitmap(it, 0f, 0f, null) }
        // reflexos nas laterais
        p.shader = LinearGradient(0f, 0f, W * 0.04f, 0f, Color.parseColor("#4A4F52"), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, W * 0.04f, H, p)
        p.shader = LinearGradient(W, 0f, W - W * 0.04f, 0f, Color.parseColor("#3A3E41"), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        c.drawRect(W - W * 0.04f, 0f, W, H, p)
        p.shader = null
        drawTop(c, W)
        drawBrandGrille(c, W)
        drawSide(c)
        drawBezel(c)
        drawLcd(c)
        for (k in keys) drawKey(c, k)
    }

    private fun drawTop(c: Canvas, W: Float) {
        // pescoço do rádio
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#0F1011")
        c.drawRoundRect(neck, W * 0.04f, W * 0.04f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f
        p.color = Color.parseColor("#2C2F31")
        c.drawRoundRect(neck, W * 0.04f, W * 0.04f, p)
        // antena
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(antenna.left, 0f, antenna.right, 0f, Color.parseColor("#3D4043"), Color.parseColor("#08090A"), Shader.TileMode.CLAMP)
        c.drawRoundRect(antenna, W * 0.03f, W * 0.03f, p)
        p.shader = null
        // botão de volume (rotativo)
        p.shader = RadialGradient(knobX - knobR * 0.3f, knobY - knobR * 0.3f, knobR * 1.4f, Color.parseColor("#3A3D40"), Color.parseColor("#0A0B0C"), Shader.TileMode.CLAMP)
        c.drawCircle(knobX, knobY, knobR, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 3f
        p.color = Color.parseColor("#5A5F63")
        c.drawCircle(knobX, knobY, knobR, p)
        p.strokeWidth = 2f
        for (i in 0 until 28) {
            val a = (i * 360f / 28f) * Math.PI.toFloat() / 180f
            p.color = Color.parseColor("#1B1D1F")
            c.drawLine(knobX + cos(a) * knobR * 0.82f, knobY + sin(a) * knobR * 0.82f, knobX + cos(a) * knobR * 0.98f, knobY + sin(a) * knobR * 0.98f, p)
        }
        val ang = (-135f + ctl.volumeNorm() * 270f - 90f) * Math.PI.toFloat() / 180f
        p.color = cAmber
        p.strokeWidth = 5f
        p.strokeCap = Paint.Cap.ROUND
        c.drawLine(knobX + cos(ang) * knobR * 0.3f, knobY + sin(ang) * knobR * 0.3f, knobX + cos(ang) * knobR * 0.78f, knobY + sin(ang) * knobR * 0.78f, p)
        p.strokeCap = Paint.Cap.BUTT
        // LED de estado (âmbar a transmitir, verde a receber, azul ligado)
        val st = CommCore.state
        p.style = Paint.Style.FILL
        p.color = when {
            st == CommCore.St.TRANSMITTING || CommCore.callActive -> cAmber
            st == CommCore.St.RECEIVING -> cGreen
            CommCore.connected() -> cAccent
            else -> Color.parseColor("#3A3D40")
        }
        c.drawCircle(knobX - knobR * 1.75f, knobY, W * 0.012f, p)
    }

    private fun drawBrandGrille(c: Canvas, W: Float) {
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#0E0F10")
        c.drawRoundRect(brand, brand.height() * 0.25f, brand.height() * 0.25f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f
        p.color = Color.parseColor("#2A2D2F")
        c.drawRoundRect(brand, brand.height() * 0.25f, brand.height() * 0.25f, p)
        text(c, "TACTICALTALK", brand.centerX(), brand.centerY() + brand.height() * 0.17f, brand.height() * 0.46f, Color.parseColor("#D9DEE2"), true, Paint.Align.CENTER, 3f)
        for (s in arrayOf(slot1, slot2)) {
            p.style = Paint.Style.FILL
            p.color = Color.parseColor("#050606")
            c.drawRoundRect(s, s.height() / 2f, s.height() / 2f, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 3f
            p.color = Color.parseColor("#2E3234")
            c.drawRoundRect(s, s.height() / 2f, s.height() / 2f, p)
            p.strokeWidth = 2f
            p.color = Color.parseColor("#151718")
            var x = s.left + s.height()
            while (x < s.right - s.height()) {
                c.drawLine(x, s.top + s.height() * 0.2f, x, s.bottom - s.height() * 0.2f, p)
                x += W * 0.022f
            }
        }
    }

    private fun drawSide(c: Canvas) {
        sideButton(c, ptt, "ptt", "PTT", Color.parseColor("#26292B"), cAmber, ctl.pttHeld)
        sideButton(c, sos, "sos", "SOS", Color.parseColor("#5C1F10"), cAmber, ctl.sosHeld)
    }

    private fun sideButton(c: Canvas, r: RectF, id: String, label: String, base: Int, ring: Int, held: Boolean) {
        val on = held || pressed.contains(id)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(r.left, 0f, r.right, 0f, if (on) Color.parseColor("#4A4F52") else base, Color.parseColor("#0B0C0D"), Shader.TileMode.CLAMP)
        c.drawRoundRect(r, r.width() * 0.35f, r.width() * 0.35f, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = if (on) 6f else 2f
        p.color = if (on) ring else Color.parseColor("#3A3E41")
        c.drawRoundRect(r, r.width() * 0.35f, r.width() * 0.35f, p)
        p.strokeWidth = 2f
        p.color = Color.parseColor("#0D0E0F")
        var y = r.top + r.width()
        while (y < r.bottom - r.width()) {
            c.drawLine(r.left + r.width() * 0.2f, y, r.right - r.width() * 0.2f, y, p)
            y += r.width() * 0.28f
        }
        c.save()
        c.rotate(-90f, r.centerX(), r.centerY())
        text(c, label, r.centerX(), r.centerY() + r.width() * 0.17f, r.width() * 0.42f, Color.parseColor("#D9DEE2"), true, Paint.Align.CENTER, 2f)
        c.restore()
    }

    private fun drawBezel(c: Canvas) {
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#040505")
        c.drawRoundRect(bezel, bezel.width() * 0.06f, bezel.width() * 0.06f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 4f
        p.color = Color.parseColor("#33373A")
        c.drawRoundRect(bezel, bezel.width() * 0.06f, bezel.width() * 0.06f, p)
    }

    private fun drawKey(c: Canvas, k: KeyBox) {
        val id = "k:" + k.key.name
        val on = pressed.contains(id)
        val r = k.r
        val rad = r.height() * 0.2f
        p.style = Paint.Style.FILL
        if (k.key == Key.UP || k.key == Key.DOWN) {
            // as duas setas formam um único bloco
            p.shader = LinearGradient(0f, r.top, 0f, r.bottom, if (on) Color.parseColor("#4B5053") else Color.parseColor("#26292B"), Color.parseColor("#121314"), Shader.TileMode.CLAMP)
            c.drawRoundRect(r, rad, rad, p)
            p.shader = null
            p.color = if (on) cAmber else Color.parseColor("#F0F2F3")
            val cx = r.centerX()
            val cy = r.centerY()
            val s = r.height() * 0.22f
            path.reset()
            if (k.key == Key.UP) {
                path.moveTo(cx, cy - s); path.lineTo(cx - s, cy + s * 0.7f); path.lineTo(cx + s, cy + s * 0.7f)
            } else {
                path.moveTo(cx, cy + s); path.lineTo(cx - s, cy - s * 0.7f); path.lineTo(cx + s, cy - s * 0.7f)
            }
            path.close()
            c.drawPath(path, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 3f
            p.color = Color.parseColor("#050505")
            c.drawRoundRect(r, rad, rad, p)
            return
        }
        p.shader = LinearGradient(0f, r.top, 0f, r.bottom, if (on) Color.parseColor("#4B5053") else Color.parseColor("#33373A"), Color.parseColor("#171819"), Shader.TileMode.CLAMP)
        c.drawRoundRect(r, rad, rad, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = if (on) 5f else 3f
        p.color = if (on) cAmber else Color.parseColor("#050505")
        c.drawRoundRect(r, rad, rad, p)
        p.strokeWidth = 1.5f
        p.color = Color.parseColor("#4A4F52")
        c.drawLine(r.left + rad, r.top + 3f, r.right - rad, r.top + 3f, p)
        val white = Color.parseColor("#F0F2F3")
        when (k.key) {
            Key.MENU -> text(c, "MENU", r.centerX(), r.centerY() + r.height() * 0.16f, r.height() * 0.36f, white, true, Paint.Align.CENTER, 1f)
            Key.GREEN -> handset(c, r, cGreen, false)
            Key.RED -> handset(c, r, cRed, true)
            Key.BACK -> backArrow(c, r, white)
            else -> {
                val big = r.height() * 0.5f
                if (k.b.isEmpty()) {
                    text(c, k.a, r.centerX(), r.centerY() + big * 0.34f, big, white, true, Paint.Align.CENTER, 0f)
                } else {
                    text(c, k.a, r.left + r.width() * 0.2f, r.centerY() + big * 0.34f, big, white, true, Paint.Align.LEFT, 0f)
                    text(c, k.b, r.left + r.width() * 0.2f + big * 0.62f, r.centerY() + big * 0.32f, r.height() * 0.27f, Color.parseColor("#C9CED2"), true, Paint.Align.LEFT, 0f)
                }
            }
        }
    }

    private fun handset(c: Canvas, r: RectF, color: Int, down: Boolean) {
        val cx = r.centerX()
        val cy = r.centerY()
        val w = r.width() * 0.26f
        p.style = Paint.Style.STROKE
        p.strokeWidth = r.height() * 0.17f
        p.strokeCap = Paint.Cap.ROUND
        p.color = color
        path.reset()
        if (down) {
            path.moveTo(cx - w, cy - r.height() * 0.02f)
            path.quadTo(cx, cy + r.height() * 0.26f, cx + w, cy - r.height() * 0.02f)
        } else {
            path.moveTo(cx - w, cy + r.height() * 0.1f)
            path.quadTo(cx, cy - r.height() * 0.2f, cx + w, cy + r.height() * 0.1f)
        }
        c.drawPath(path, p)
        p.strokeCap = Paint.Cap.BUTT
    }

    /** Seta curva de "voltar" (↩): linha, curva de retorno e ponta à esquerda, centrada no botão. */
    private fun backArrow(c: Canvas, r: RectF, color: Int) {
        val cy = r.centerY()
        val s = min(r.height(), r.width()) * 0.27f
        val rad = s * 0.62f
        val ox = r.centerX() - s * 0.23f
        p.style = Paint.Style.STROKE
        p.strokeWidth = r.height() * 0.085f
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.color = color
        path.reset()
        path.moveTo(ox - s * 0.55f, cy - rad)
        path.lineTo(ox + s * 0.55f, cy - rad)
        path.arcTo(RectF(ox + s * 0.55f - rad, cy - rad, ox + s * 0.55f + rad, cy + rad), -90f, 180f)
        path.lineTo(ox - s * 0.7f, cy + rad)
        c.drawPath(path, p)
        path.reset()
        path.moveTo(ox - s * 0.7f + s * 0.62f, cy + rad - s * 0.55f)
        path.lineTo(ox - s * 0.7f, cy + rad)
        path.lineTo(ox - s * 0.7f + s * 0.62f, cy + rad + s * 0.55f)
        c.drawPath(path, p)
        p.strokeCap = Paint.Cap.BUTT
        p.strokeJoin = Paint.Join.MITER
    }

    // ------------------------------------------------------------------ LCD

    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean, align: Paint.Align, spacing: Float = 0f) {
        tp.reset()
        tp.isAntiAlias = true
        tp.textSize = size
        tp.color = color
        tp.typeface = if (bold) Typeface.create("sans-serif-medium", Typeface.BOLD) else Typeface.create("sans-serif", Typeface.NORMAL)
        tp.textAlign = align
        tp.letterSpacing = spacing / max(size, 1f)
        c.drawText(s, x, y, tp)
    }

    private fun fit(s: String, size: Float, width: Float, bold: Boolean = false): String {
        tp.reset()
        tp.textSize = size
        tp.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        return TextUtils.ellipsize(s, tp, width, TextUtils.TruncateAt.END).toString()
    }

    private fun mmss(since: Long): String {
        if (since == 0L) return "00:00"
        val s = ((SystemClock.elapsedRealtime() - since) / 1000).toInt().coerceAtLeast(0)
        return String.format("%02d:%02d", s / 60, s % 60)
    }

    private fun drawLcd(c: Canvas) {
        c.save()
        val clip = Path()
        clip.addRoundRect(lcd, lcd.width() * 0.04f, lcd.width() * 0.04f, Path.Direction.CW)
        c.clipPath(clip)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, lcd.top, 0f, lcd.bottom, cBlue1, cBlue2, Shader.TileMode.CLAMP)
        c.drawRect(lcd, p)
        p.shader = null
        val u = lcd.width() / 100f
        drawStatusBar(c, u)
        val ed = ctl.edit
        val st = CommCore.state
        val talking = st == CommCore.St.TRANSMITTING || st == CommCore.St.RECEIVING || CommCore.callActive
        when {
            ed != null -> drawEdit(c, u, ed)
            talking -> drawTalk(c, u)
            ctl.menu != null -> drawList(c, u, ctl.menu!!)
            ctl.infoPage == 1 -> drawSignal(c, u)
            ctl.infoPage == 2 -> drawNotifs(c, u)
            else -> drawHome(c, u)
        }
        val msg = ctl.currentToast() ?: CommCore.banner
        if (msg != null) {
            val urgent = CommCore.banner != null && ctl.currentToast() == null
            p.style = Paint.Style.FILL
            p.color = if (urgent) Color.parseColor("#B8352F") else Color.parseColor("#C98A1F")
            rect.set(lcd.left + 2 * u, lcd.top + 10.5f * u, lcd.right - 2 * u, lcd.top + 17f * u)
            c.drawRoundRect(rect, 2 * u, 2 * u, p)
            text(c, fit(msg, 3.4f * u, rect.width() - 3 * u, true), rect.centerX(), rect.centerY() + 1.2f * u, 3.4f * u, Color.WHITE, true, Paint.Align.CENTER)
        }
        c.restore()
    }

    private fun timeText(): String = try {
        android.text.format.DateFormat.getTimeFormat(context).format(java.util.Date()) // hora e fuso REAIS do Android
    } catch (e: Exception) {
        ""
    }

    private fun drawStatusBar(c: Canvas, u: Float) {
        val top = lcd.top
        // 1) rede móvel do TELEFONE (real; "—" quando o Android não diz)
        val net = PhoneNet.label
        text(c, net, lcd.left + 3 * u, top + 6.4f * u, 3.5f * u, Color.WHITE, true, Paint.Align.LEFT)
        val bx0 = lcd.left + 3 * u + (if (net.length >= 3) 7.5f else 6f) * u
        val lvl = PhoneNet.level
        p.style = Paint.Style.FILL
        for (i in 0 until 4) {
            val h = (1.8f + i * 1.45f) * u
            p.color = if (lvl >= 0 && i < lvl) Color.WHITE else Color.parseColor("#3E5C9E")
            rect.set(bx0 + i * 2.1f * u, top + 7.5f * u - h, bx0 + i * 2.1f * u + 1.4f * u, top + 7.5f * u)
            c.drawRect(rect, p)
        }
        // 2) ligação TacticalTalk entre rádios (separada da rede móvel)
        val q = CommCore.quality()
        p.color = when (q) {
            CommCore.Q.STABLE -> cGreen
            CommCore.Q.WEAK, CommCore.Q.RECOVERING -> cAmber
            CommCore.Q.LOST -> cRed
            else -> Color.parseColor("#3E5C9E")
        }
        c.drawCircle(lcd.left + 25.5f * u, top + 4.6f * u, 1.2f * u, p)
        val short = when (CommCore.activeTransport) {
            Transport.WIFI_DIRECT -> "WFD"
            Transport.HOTSPOT -> "HOT"
            Transport.BLUETOOTH -> "BT"
            else -> "—"
        }
        text(c, short, lcd.left + 28 * u, top + 6.4f * u, 3.3f * u, Color.WHITE, true, Paint.Align.LEFT)
        // 3) hora
        text(c, timeText(), lcd.left + 50 * u, top + 6.4f * u, 3.5f * u, Color.WHITE, true, Paint.Align.CENTER)
        // 4) participantes
        val px = lcd.left + 64 * u
        p.color = Color.WHITE
        c.drawCircle(px, top + 3.4f * u, 1f * u, p)
        c.drawCircle(px - 1.8f * u, top + 4.2f * u, 0.8f * u, p)
        c.drawCircle(px + 1.8f * u, top + 4.2f * u, 0.8f * u, p)
        text(c, CommCore.participants.size.toString(), px + 3.2f * u, top + 6.4f * u, 3.5f * u, Color.WHITE, true, Paint.Align.LEFT)
        // 5) bateria REAL do telefone
        val bat = ctl.batteryPct
        val bx = lcd.right - 21 * u
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.2f
        p.color = Color.WHITE
        rect.set(bx, top + 2.6f * u, bx + 8 * u, top + 6.8f * u)
        c.drawRoundRect(rect, u, u, p)
        p.style = Paint.Style.FILL
        p.color = if (bat < 20 && !ctl.charging) cRed else cGreen
        rect.set(bx + 0.5f * u, top + 3.1f * u, bx + 0.5f * u + 7f * u * bat / 100f, top + 6.3f * u)
        c.drawRect(rect, p)
        if (ctl.charging) {
            p.color = Color.WHITE
            path.reset()
            val cx = bx + 4 * u
            val cy = top + 4.7f * u
            path.moveTo(cx + 0.6f * u, cy - 1.7f * u); path.lineTo(cx - 1.2f * u, cy + 0.2f * u); path.lineTo(cx, cy + 0.2f * u)
            path.lineTo(cx - 0.6f * u, cy + 1.7f * u); path.lineTo(cx + 1.2f * u, cy - 0.2f * u); path.lineTo(cx, cy - 0.2f * u); path.close()
            c.drawPath(path, p)
        }
        text(c, "$bat%", lcd.right - 2.5f * u, top + 6.4f * u, 3.4f * u, Color.WHITE, true, Paint.Align.RIGHT)
    }

    private val cardRect = RectF()

    private fun drawHome(c: Canvas, u: Float) {
        val top = lcd.top + 10 * u
        // logótipo
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        rect.set(lcd.left + 4 * u, top + 1.5f * u, lcd.left + 8.6f * u, top + 10.5f * u)
        c.drawRoundRect(rect, u, u, p)
        p.color = cBlue2
        rect.set(lcd.left + 5.2f * u, top + 5.5f * u, lcd.left + 7.4f * u, top + 7 * u)
        c.drawRect(rect, p)
        text(c, "TacticalTalk", lcd.left + 11 * u, top + 7.2f * u, 6.6f * u, Color.WHITE, true, Paint.Align.LEFT)
        text(c, "Comunica. Em qualquer lugar.", lcd.left + 11.4f * u, top + 11.2f * u, 2.9f * u, cMuted, false, Paint.Align.LEFT)
        // cartão do canal (tocar = abrir a lista de canais)
        cardRect.set(lcd.left + 3 * u, top + 14 * u, lcd.right - 3 * u, soft[0].top - 2 * u)
        p.color = Color.parseColor("#1D56C8")
        c.drawRoundRect(cardRect, 3 * u, 3 * u, p)
        val x = cardRect.left + 4 * u
        val maxW = cardRect.width() - 22 * u
        text(c, "Canal " + CommCore.channelNumber, x, cardRect.top + 7f * u, 5.6f * u, Color.WHITE, true, Paint.Align.LEFT)
        if (CommCore.channelProtected(CommCore.channelNumber)) {
            text(c, "PROTEGIDO", x + 24 * u, cardRect.top + 6.6f * u, 2.8f * u, cAmber, true, Paint.Align.LEFT)
        }
        text(c, fitShrink(Prefs.channelName(context, CommCore.channelNumber), 3.8f * u, maxW), x, cardRect.top + 12.4f * u, 3.8f * u, cMuted, false, Paint.Align.LEFT)
        val lineH = 5.2f * u
        var y = cardRect.top + 12.4f * u + lineH + 0.6f * u
        val lim = cardRect.bottom - 1f * u
        if (y < lim) {
            text(c, fit("Rede móvel: " + PhoneNet.summary(), 3.1f * u, cardRect.width() - 8 * u), x, y, 3.1f * u, Color.WHITE, false, Paint.Align.LEFT)
            y += lineH
        }
        if (y < lim) {
            val tt = if (CommCore.connected()) "TacticalTalk: " + (CommCore.activeTransport?.label ?: "") + " · sem Internet" else "TacticalTalk: sem ligação"
            text(c, fit(tt, 3.1f * u, cardRect.width() - 8 * u), x, y, 3.1f * u, Color.WHITE, false, Paint.Align.LEFT)
            y += lineH
        }
        if (y < lim) {
            val q = CommCore.quality()
            p.color = when (q) {
                CommCore.Q.STABLE -> cGreen
                CommCore.Q.WEAK, CommCore.Q.RECOVERING -> cAmber
                CommCore.Q.LOST -> cRed
                else -> Color.parseColor("#6B7FA8")
            }
            c.drawCircle(x + 1.2f * u, y - 1.1f * u, 1.4f * u, p)
            val d = CommCore.detail.substringBefore('\n')
            val line = when {
                d.isNotEmpty() -> d
                CommCore.connected() -> "Online" + (if (CommCore.mode == CommCore.Mode.CALL) " · Chamada" else "")
                CommCore.state == CommCore.St.SEARCHING -> "A procurar…"
                CommCore.state == CommCore.St.CONNECTING -> "A ligar…"
                else -> "Offline"
            }
            text(c, fit(line, 3.1f * u, cardRect.width() - 14 * u), x + 4 * u, y, 3.1f * u, if (d.isNotEmpty()) cAmber else Color.WHITE, false, Paint.Align.LEFT)
        }
        // altifalante
        p.color = cAccent
        rect.set(cardRect.right - 15 * u, cardRect.top + 3 * u, cardRect.right - 4 * u, cardRect.top + 12 * u)
        c.drawRoundRect(rect, 3 * u, 3 * u, p)
        p.color = Color.WHITE
        path.reset()
        val sx = rect.left + 3 * u
        val sy = rect.centerY()
        path.moveTo(sx, sy - 1.2f * u); path.lineTo(sx + 2 * u, sy - 1.2f * u); path.lineTo(sx + 4.5f * u, sy - 3 * u)
        path.lineTo(sx + 4.5f * u, sy + 3 * u); path.lineTo(sx + 2 * u, sy + 1.2f * u); path.lineTo(sx, sy + 1.2f * u); path.close()
        c.drawPath(path, p)
        // teclas tácteis do LCD
        val labels = arrayOf("Grupos", "Canais", "Definições")
        p.color = Color.parseColor("#0A2A70")
        c.drawRect(lcd.left, soft[0].top, lcd.right, lcd.bottom, p)
        for (i in 0 until 3) {
            val r = soft[i]
            if (pressed.contains("soft$i")) {
                p.color = cAccent
                c.drawRect(r, p)
            }
            p.color = Color.WHITE
            val ix = r.centerX()
            val iy = r.top + r.height() * 0.36f
            when (i) {
                0 -> {
                    c.drawCircle(ix, iy - u, 1.5f * u, p); c.drawCircle(ix - 3 * u, iy + 0.6f * u, 1.2f * u, p); c.drawCircle(ix + 3 * u, iy + 0.6f * u, 1.2f * u, p)
                }
                1 -> {
                    p.style = Paint.Style.STROKE
                    p.strokeWidth = 0.9f * u
                    c.drawCircle(ix, iy, 1.2f * u, p); c.drawCircle(ix, iy, 3f * u, p)
                    p.style = Paint.Style.FILL
                }
                else -> {
                    p.style = Paint.Style.STROKE
                    p.strokeWidth = 1.1f * u
                    c.drawCircle(ix, iy, 2.8f * u, p)
                    p.style = Paint.Style.FILL
                    c.drawCircle(ix, iy, 1f * u, p)
                }
            }
            text(c, labels[i], ix, r.bottom - r.height() * 0.17f, 3.4f * u, Color.WHITE, false, Paint.Align.CENTER)
        }
    }

    /** Reduz o tamanho do texto até caber; só se mesmo assim não couber usa "…". */
    private fun fitShrink(s: String, size: Float, width: Float): String {
        var sz = size
        tp.reset()
        tp.typeface = Typeface.DEFAULT
        while (sz > size * 0.7f) {
            tp.textSize = sz
            if (tp.measureText(s) <= width) break
            sz -= size * 0.05f
        }
        tp.textSize = max(sz, size * 0.7f)
        return TextUtils.ellipsize(s, tp, width, TextUtils.TruncateAt.END).toString()
    }

    private fun drawTitle(c: Canvas, u: Float, title: String) {
        val y = lcd.top + 10 * u
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#123C93")
        rect.set(lcd.left, y, lcd.right, y + 8 * u)
        c.drawRect(rect, p)
        // chevron "<": tocar = voltar (igual à tecla de voltar)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 0.9f * u
        p.strokeCap = Paint.Cap.ROUND
        p.color = Color.WHITE
        path.reset()
        path.moveTo(lcd.left + 5.2f * u, y + 2.2f * u); path.lineTo(lcd.left + 3.2f * u, y + 4f * u); path.lineTo(lcd.left + 5.2f * u, y + 5.8f * u)
        c.drawPath(path, p)
        p.strokeCap = Paint.Cap.BUTT
        text(c, fit(title, 4.4f * u, lcd.width() - 14 * u, true), lcd.left + 8 * u, y + 5.7f * u, 4.4f * u, Color.WHITE, true, Paint.Align.LEFT)
    }

    private fun drawList(c: Canvas, u: Float, m: MenuDef) {
        drawTitle(c, u, m.title)
        val items = m.items()
        val rowH = 11.5f * u
        val y0 = lcd.top + 19 * u
        val bottom = lcd.bottom - 5 * u
        val visible = max(1, ((bottom - y0) / rowH).toInt())
        listY0 = y0
        listRowH = rowH
        listVisible = visible
        if (m.title != lastListKey) {
            lastListKey = m.title
            viewFirst = 0
            scrollAnim = 0f
        }
        val sel = ctl.sel.coerceIn(0, max(0, items.size - 1))
        if (sel < viewFirst) viewFirst = sel
        if (sel > viewFirst + visible - 1) viewFirst = sel - visible + 1
        viewFirst = viewFirst.coerceIn(0, max(0, items.size - visible))
        scrollAnim += (viewFirst - scrollAnim) * 0.3f // deslocamento suave
        if (abs(viewFirst - scrollAnim) < 0.02f) scrollAnim = viewFirst.toFloat() else postInvalidateOnAnimation()
        c.save()
        c.clipRect(lcd.left, y0, lcd.right, bottom + 1.2f * u)
        val from = floor(scrollAnim).toInt().coerceAtLeast(0)
        for (idx in from..min(items.size - 1, from + visible + 1)) {
            val it = items[idx]
            val y = y0 + (idx - scrollAnim) * rowH
            rect.set(lcd.left + 2 * u, y, lcd.right - 4 * u, y + rowH - 1.2f * u)
            p.style = Paint.Style.FILL
            p.color = if (idx == sel) Color.parseColor("#2F6BEA") else Color.parseColor("#0C2F7A")
            c.drawRoundRect(rect, 2 * u, 2 * u, p)
            text(c, (idx + 1).toString(), rect.left + 3 * u, rect.centerY() + 1.5f * u, 4.2f * u, cMuted, true, Paint.Align.LEFT)
            val tw = rect.width() - (if (it.value.isNotEmpty()) 30 else 18) * u
            text(c, fit(it.title, 4.2f * u, tw, true), rect.left + 8 * u, rect.top + (if (it.sub.isEmpty()) 7f else 5.2f) * u, 4.2f * u, Color.WHITE, true, Paint.Align.LEFT)
            if (it.sub.isNotEmpty()) text(c, fit(it.sub, 2.9f * u, tw), rect.left + 8 * u, rect.top + 9.2f * u, 2.9f * u, cMuted, false, Paint.Align.LEFT)
            val ck = it.checked
            if (it.value.isNotEmpty()) {
                val col = if (ck == true) cGreen else if (ck == false) Color.parseColor("#9DB4E8") else Color.WHITE
                text(c, it.value, rect.right - 3 * u, rect.centerY() + 1.4f * u, 3.6f * u, col, true, Paint.Align.RIGHT)
            } else if (ck == true) {
                p.color = cGreen
                c.drawCircle(rect.right - 5 * u, rect.centerY(), 2 * u, p)
            }
        }
        c.restore()
        if (items.size > visible) { // barra de deslocamento: mostra que há mais itens
            val th = bottom - y0
            val thumbH = max(4 * u, th * visible / items.size)
            val range = (items.size - visible).toFloat()
            val ty = y0 + (scrollAnim / range) * (th - thumbH)
            p.style = Paint.Style.FILL
            p.color = Color.parseColor("#33FFFFFF")
            rect.set(lcd.right - 2.6f * u, y0, lcd.right - 1.6f * u, bottom)
            c.drawRoundRect(rect, u, u, p)
            p.color = Color.WHITE
            rect.set(lcd.right - 2.6f * u, ty, lcd.right - 1.6f * u, ty + thumbH)
            c.drawRoundRect(rect, u, u, p)
        }
        val hint = if (CommCore.detail.isNotEmpty()) CommCore.detail.substringBefore('\n') else "Setas ou deslizar · MENU ou tocar: escolher · voltar"
        text(c, fit(hint, 2.9f * u, lcd.width() - 6 * u), lcd.left + 3 * u, lcd.bottom - 1.6f * u, 2.9f * u, cMuted, false, Paint.Align.LEFT)
    }

    private fun drawWave(c: Canvas, u: Float, data: FloatArray, color: Int, cy: Float) {
        p.style = Paint.Style.FILL
        p.color = color
        val n = data.size
        val bw = (lcd.width() - 10 * u) / n
        for (i in 0 until n) {
            val v = data[i].coerceIn(0f, 1f)
            val h = (0.8f + v * 9f) * u
            rect.set(lcd.left + 5 * u + i * bw, cy - h / 2f, lcd.left + 5 * u + i * bw + bw * 0.6f, cy + h / 2f)
            c.drawRect(rect, p)
        }
    }

    private fun drawTalk(c: Canvas, u: Float) {
        val tx = CommCore.state == CommCore.St.TRANSMITTING || (CommCore.callActive && CommCore.txSince != 0L)
        val rx = CommCore.state == CommCore.St.RECEIVING
        val title = Prefs.channelLabel(context, CommCore.channelNumber)
        drawTitle(c, u, title)
        val cy = lcd.top + 36 * u
        if (tx) drawWave(c, u, CommCore.waveTx, cAmber, cy - 9 * u)
        if (rx || CommCore.callActive) drawWave(c, u, CommCore.waveRx, cAccent.let { Color.parseColor("#7FB2FF") }, if (tx) cy + 20 * u else cy - 9 * u)
        val ring = if (tx) cAmber else Color.parseColor("#7FB2FF")
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.2f * u
        p.color = ring
        c.drawCircle(lcd.centerX(), cy + 6 * u, 8 * u, p)
        p.style = Paint.Style.FILL
        p.color = ring
        if (tx) {
            rect.set(lcd.centerX() - 2 * u, cy + 1.5f * u, lcd.centerX() + 2 * u, cy + 8 * u)
            c.drawRoundRect(rect, 2 * u, 2 * u, p)
            rect.set(lcd.centerX() - 3.4f * u, cy + 5 * u, lcd.centerX() + 3.4f * u, cy + 10 * u)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 0.9f * u
            c.drawArc(rect, 0f, 180f, false, p)
            p.style = Paint.Style.FILL
        } else {
            path.reset()
            val sx = lcd.centerX() - 3 * u
            val sy = cy + 6 * u
            path.moveTo(sx, sy - 1.6f * u); path.lineTo(sx + 2.5f * u, sy - 1.6f * u); path.lineTo(sx + 6 * u, sy - 4 * u)
            path.lineTo(sx + 6 * u, sy + 4 * u); path.lineTo(sx + 2.5f * u, sy + 1.6f * u); path.lineTo(sx, sy + 1.6f * u); path.close()
            c.drawPath(path, p)
        }
        val label = when {
            CommCore.callActive -> "Chamada ao vivo"
            tx -> "A falar…"
            else -> "Recebendo áudio…"
        }
        text(c, label, lcd.centerX(), cy + 22 * u, 5f * u, Color.WHITE, true, Paint.Align.CENTER)
        val since = if (tx) CommCore.txSince else CommCore.rxSince
        text(c, mmss(since) + (if (!tx && CommCore.rxName != null) " · " + CommCore.rxName else ""), lcd.centerX(), cy + 28.5f * u, 4f * u, cMuted, false, Paint.Align.CENTER)
    }

    private fun drawSignal(c: Canvas, u: Float) {
        drawTitle(c, u, "Sinal")
        // A) rede móvel do TELEFONE (não é a ligação entre rádios)
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#0C2F7A")
        rect.set(lcd.left + 2 * u, lcd.top + 20 * u, lcd.right - 2 * u, lcd.top + 36 * u)
        c.drawRoundRect(rect, 2 * u, 2 * u, p)
        text(c, "Rede móvel do telefone", rect.left + 3 * u, rect.top + 4.6f * u, 3.7f * u, Color.WHITE, true, Paint.Align.LEFT)
        text(c, fit(PhoneNet.summary() + " · " + PhoneNet.detail, 3f * u, rect.width() - 6 * u), rect.left + 3 * u, rect.top + 9.2f * u, 3f * u, cMuted, false, Paint.Align.LEFT)
        text(c, fit(PhoneNet.frequency(), 2.8f * u, rect.width() - 6 * u), rect.left + 3 * u, rect.top + 13.6f * u, 2.8f * u, cMuted, false, Paint.Align.LEFT)
        // B) ligação TacticalTalk entre rádios
        val q = CommCore.quality()
        val score = CommCore.qualityScore()
        val (label, col) = when (q) {
            CommCore.Q.STABLE -> Pair("Ligação estável", cGreen)
            CommCore.Q.WEAK -> Pair("Ligação fraca", cAmber)
            CommCore.Q.RECOVERING -> Pair("A recuperar", cAmber)
            CommCore.Q.LOST -> Pair("Ligação perdida", cRed)
            else -> Pair("Sem ligação TacticalTalk", Color.parseColor("#9DB4E8"))
        }
        text(c, label + (if (CommCore.connected()) " · $score/100" else ""), lcd.left + 3 * u, lcd.top + 42 * u, 4f * u, col, true, Paint.Align.LEFT)
        var ly = lcd.top + 51 * u
        val links = CommCore.links()
        for (l in links.take(2)) {
            p.style = Paint.Style.FILL
            p.color = Color.parseColor("#0C2F7A")
            rect.set(lcd.left + 2 * u, ly - 4.2f * u, lcd.right - 2 * u, ly + 4.6f * u)
            c.drawRoundRect(rect, 2 * u, 2 * u, p)
            text(c, l.transport.label + if (l.active) " (activo)" else " (espera)", rect.left + 3 * u, ly - 0.2f * u, 3.6f * u, Color.WHITE, true, Paint.Align.LEFT)
            val rtt = if (l.rttMs < 0) "—" else l.rttMs.toString() + " ms"
            text(c, "RTT $rtt · perda ${l.lossPct}% · ${l.score}/100", rect.left + 3 * u, ly + 3.5f * u, 2.8f * u, cMuted, false, Paint.Align.LEFT)
            ly += 10 * u
        }
        val reason = CommCore.linkReason
        if (reason.isNotEmpty()) text(c, fit(reason, 2.8f * u, lcd.width() - 6 * u), lcd.left + 3 * u, lcd.bottom - 1.6f * u, 2.8f * u, cAmber, false, Paint.Align.LEFT)
    }

    private fun drawNotifs(c: Canvas, u: Float) {
        drawTitle(c, u, "Estado geral")
        val y = lcd.top + 19 * u
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#2F6BEA")
        rect.set(lcd.left + 3 * u, y, lcd.right - 3 * u, y + 17 * u)
        c.drawRoundRect(rect, 2.5f * u, 2.5f * u, p)
        text(c, Prefs.channelLabel(context, CommCore.channelNumber), rect.left + 4 * u, y + 6.5f * u, 4.6f * u, Color.WHITE, true, Paint.Align.LEFT)
        val ev = if (CommCore.events.isEmpty()) "Sem eventos" else CommCore.events[0]
        text(c, fit(ev, 3.4f * u, rect.width() - 8 * u), rect.left + 4 * u, y + 13 * u, 3.4f * u, Color.WHITE, false, Paint.Align.LEFT)
        val y2 = y + 20 * u
        p.color = Color.parseColor("#0C2F7A")
        rect.set(lcd.left + 3 * u, y2, lcd.right - 3 * u, y2 + 12 * u)
        c.drawRoundRect(rect, 2.5f * u, 2.5f * u, p)
        val ql = when (CommCore.quality()) {
            CommCore.Q.STABLE -> "Ligação estável"
            CommCore.Q.WEAK -> "Ligação fraca"
            CommCore.Q.RECOVERING -> "A recuperar"
            CommCore.Q.LOST -> "Ligação perdida"
            else -> "Sem ligação"
        }
        text(c, ql, rect.left + 4 * u, y2 + 5f * u, 3.9f * u, Color.WHITE, true, Paint.Align.LEFT)
        text(c, CommCore.activeTransport?.label ?: "—", rect.left + 4 * u, y2 + 9.6f * u, 3.1f * u, cMuted, false, Paint.Align.LEFT)
        val vals = arrayOf("AUDIO" to Prefs.voiceVolume(ctx).toString() + "%", "GRUPO" to CommCore.participants.size.toString(), "SINAL" to CommCore.qualityScore().toString(), "BATERIA" to ctl.batteryPct.toString() + "%")
        val bw = lcd.width() / 4f
        for (i in 0 until 4) {
            val cx = lcd.left + bw * i + bw / 2f
            val cy = lcd.bottom - 13 * u
            p.style = Paint.Style.STROKE
            p.strokeWidth = 0.9f * u
            p.color = cGreen
            c.drawCircle(cx, cy, 5.4f * u, p)
            text(c, vals[i].second, cx, cy + 1.4f * u, 3.4f * u, Color.WHITE, true, Paint.Align.CENTER)
            text(c, vals[i].first, cx, lcd.bottom - 2.6f * u, 2.7f * u, cMuted, true, Paint.Align.CENTER)
        }
    }

    private val btnSave = RectF()
    private val btnCancel = RectF()
    private val btnAndroid = RectF()

    private fun textW(str: String, size: Float, bold: Boolean): Float {
        tp.reset()
        tp.textSize = size
        tp.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        return tp.measureText(str)
    }

    private fun drawEdit(c: Canvas, u: Float, e: EditState) {
        drawTitle(c, u, e.title)
        val now = SystemClock.elapsedRealtime()
        val live = e.ed.pendingLive(now)
        val raw = e.ed.text
        // campo de texto
        rect.set(lcd.left + 3 * u, lcd.top + 20 * u, lcd.right - 3 * u, lcd.top + 32 * u)
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#0A2A70")
        c.drawRoundRect(rect, 2 * u, 2 * u, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.2f
        p.color = cAccent
        c.drawRoundRect(rect, 2 * u, 2 * u, p)
        val head = if (raw.isEmpty()) "" else raw.dropLast(1)
        val last = if (raw.isEmpty()) "" else raw.last().toString()
        val shownHead = if (e.secret) "•".repeat(head.length) else head
        val shownLast = if (e.secret && !live) "•" else last
        var sz = 5.4f * u
        while (sz > 3f * u && textW(shownHead + shownLast + "|", sz, true) > rect.width() - 4 * u) sz -= 0.3f * u
        val tx = rect.left + 2.5f * u
        val ty = rect.centerY() + sz * 0.34f
        text(c, shownHead, tx, ty, sz, Color.WHITE, true, Paint.Align.LEFT)
        val hw = textW(shownHead, sz, true)
        text(c, shownLast, tx + hw, ty, sz, if (live) cAmber else Color.WHITE, true, Paint.Align.LEFT)
        if ((now / 500) % 2 == 0L) {
            val cx = tx + hw + textW(shownLast, sz, true) + 0.4f * u
            p.style = Paint.Style.FILL
            p.color = Color.WHITE
            rect.set(cx, rect.top + 2.2f * u, cx + 0.5f * u, rect.bottom - 2.2f * u)
            c.drawRect(rect, p)
        }
        text(c, raw.length.toString() + "/" + e.ed.max + (if (e.secret) " · mín. " + e.minLen else ""), lcd.right - 3 * u, lcd.top + 36.2f * u, 2.9f * u, cMuted, false, Paint.Align.RIGHT)
        text(c, "2-9 letras (toques repetidos) · 0 espaço", lcd.left + 3 * u, lcd.top + 36.2f * u, 2.9f * u, Color.WHITE, false, Paint.Align.LEFT)
        text(c, "* apagar · # limpar" + (if (e.secret) " · cima: Aa" else ""), lcd.left + 3 * u, lcd.top + 40.6f * u, 2.9f * u, Color.WHITE, false, Paint.Align.LEFT)
        // botões tácteis (mesma lógica das teclas MENU / voltar)
        val by = lcd.bottom - 12.5f * u
        btnSave.set(lcd.left + 3 * u, by, lcd.centerX() - 1 * u, by + 9 * u)
        btnCancel.set(lcd.centerX() + 1 * u, by, lcd.right - 3 * u, by + 9 * u)
        btnAndroid.set(lcd.left + 3 * u, by - 10.5f * u, lcd.right - 3 * u, by - 1.8f * u)
        for ((r, label, col) in listOf(Triple(btnSave, "Guardar", cAccent), Triple(btnCancel, "Cancelar", Color.parseColor("#6B7FA8")), Triple(btnAndroid, "Usar teclado do Android", Color.parseColor("#123C93")))) {
            p.style = Paint.Style.FILL
            p.color = col
            c.drawRoundRect(r, 2 * u, 2 * u, p)
            text(c, label, r.centerX(), r.centerY() + 1.2f * u, 3.6f * u, Color.WHITE, true, Paint.Align.CENTER)
        }
    }

    // ------------------------------------------------------------------ toque

    private fun hit(x: Float, y: Float): String? {
        if (hypot(x - knobX, y - knobY) <= knobR * 1.25f) return "knob"
        if (ptt.contains(x, y)) return "ptt"
        if (sos.contains(x, y)) return "sos"
        for (k in keys) if (k.r.contains(x, y)) return "k:" + k.key.name
        if (!lcd.contains(x, y)) return null
        val u = lcd.width() / 100f
        if (ctl.edit != null) {
            if (btnSave.contains(x, y)) return "ed_save"
            if (btnCancel.contains(x, y)) return "ed_cancel"
            if (btnAndroid.contains(x, y)) return "ed_android"
            return null
        }
        if (y < lcd.top + 10 * u) return if (x < lcd.left + 40 * u) "stat0" else if (x < lcd.left + 76 * u) "stat1" else "stat2"
        if (ctl.menu != null) {
            if (y < lcd.top + 18 * u && x < lcd.left + 16 * u) return "lcd_back"
            if (y >= listY0 && y <= listY0 + listVisible * listRowH) return "lcd_list"
            return null
        }
        if (ctl.infoPage == 0) {
            for (i in 0 until 3) if (soft[i].contains(x, y)) return "soft$i"
            if (cardRect.contains(x, y)) return "card"
        }
        return null
    }

    private fun angle(x: Float, y: Float): Float = Math.toDegrees(atan2((y - knobY).toDouble(), (x - knobX).toDouble())).toFloat()

    private var lcdLastY = 0f
    private var lcdMoved = false
    private var lcdRow = 0

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                val id = hit(e.getX(i), e.getY(i))
                if (id != null) {
                    active[e.getPointerId(i)] = id
                    pressed.add(id)
                    when {
                        id == "knob" -> knobLast = angle(e.getX(i), e.getY(i))
                        id == "ptt" -> ctl.sideDown(false)
                        id == "sos" -> ctl.sideDown(true)
                        id.startsWith("soft") -> ctl.soft(id.substring(4).toInt())
                        id.startsWith("stat") -> ctl.tapStatus(id.substring(4).toInt())
                        id == "card" -> ctl.tapCard()
                        id == "lcd_back" -> ctl.tapBack()
                        id == "ed_save" -> ctl.editSave()
                        id == "ed_cancel" -> ctl.editCancel()
                        id == "ed_android" -> ctl.editAndroid()
                        id == "lcd_list" -> {
                            lcdLastY = e.getY(i)
                            lcdMoved = false
                            lcdRow = floor((e.getY(i) - listY0) / listRowH + scrollAnim).toInt()
                        }
                        id.startsWith("k:") -> ctl.press(Key.valueOf(id.substring(2)))
                    }
                    invalidate()
                }
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) {
                    val id = active[e.getPointerId(i)]
                    if (id == "knob") {
                        val a = angle(e.getX(i), e.getY(i))
                        var d = a - knobLast
                        while (d > 180f) d -= 360f
                        while (d < -180f) d += 360f
                        knobLast = a
                        ctl.setVolumeNorm(ctl.volumeNorm() + d / 270f)
                        invalidate()
                    } else if (id == "lcd_list") {
                        val dy = e.getY(i) - lcdLastY
                        if (abs(dy) >= listRowH * 0.7f) { // deslizar o dedo = mover o destaque (como as setas)
                            ctl.moveSel(if (dy < 0) 1 else -1)
                            lcdLastY = e.getY(i)
                            lcdMoved = true
                            invalidate()
                        }
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                val cancel = e.actionMasked == MotionEvent.ACTION_CANCEL
                val ids = if (cancel) ArrayList(active.keys) else arrayListOf(e.getPointerId(e.actionIndex))
                for (pid in ids) {
                    val id = active.remove(pid) ?: continue
                    pressed.remove(id)
                    if (id == "ptt") ctl.sideUp(false)
                    if (id == "sos") ctl.sideUp(true)
                    if (id == "lcd_list" && !lcdMoved && !cancel) ctl.tapRow(lcdRow)
                }
                if (!cancel && e.actionMasked == MotionEvent.ACTION_UP) performClick()
                invalidate()
            }
        }
        return true
    }

    override fun performClick(): Boolean = super.performClick()

    // ------------------------------------------------------------------ actualização

    private val refresher = object : Runnable {
        override fun run() {
            invalidate()
            val st = CommCore.state
            val fast = st == CommCore.St.TRANSMITTING || st == CommCore.St.RECEIVING || CommCore.callActive
            postDelayed(this, if (fast) 100L else 800L)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        post(refresher)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(refresher)
        super.onDetachedFromWindow()
    }
}
