package com.tacticaltalk.app

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.wifi.WpsInfo
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pInfo
import android.net.wifi.p2p.WifiP2pManager
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import java.io.IOException
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket

/**
 * Wi-Fi Direct: descoberta, ligação e criação do socket TCP.
 * O "group owner" abre o servidor (porta Protocol.PORT); o outro liga-se ao endereço do group owner.
 * Todos os callbacks do Listener chegam na thread principal.
 */
@SuppressLint("MissingPermission")
class WifiDirectController(private val ctx: Context, private val l: Listener) {

    interface Listener {
        fun onP2pState(enabled: Boolean)
        fun onPeers(list: List<WifiP2pDevice>)
        fun onDiscoveryStarted()
        fun onDiscoveryFailed(reason: Int)
        fun onConnecting()
        fun onConnectFailed(reason: Int)
        fun onSocketReady(socket: Socket, isOwner: Boolean)
        fun onSocketFailed()
        fun onGroupLost()
        fun onSecurityError()
    }

    private val handler = Handler(Looper.getMainLooper())
    private val manager: WifiP2pManager? =
        ctx.getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager
    private var channel: WifiP2pManager.Channel? = null
    private var registered = false
    @Volatile private var socketStarted = false
    @Volatile private var acceptSocket: ServerSocket? = null

    val supported: Boolean
        get() = manager != null && ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_WIFI_DIRECT)

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION -> {
                    val st = i.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1)
                    l.onP2pState(st == WifiP2pManager.WIFI_P2P_STATE_ENABLED)
                }
                WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION -> requestPeers()
                WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION -> requestConnection()
            }
        }
    }

    fun register() {
        val m = manager ?: return
        if (!supported || registered) return
        channel = m.initialize(ctx, Looper.getMainLooper(), null)
        val f = IntentFilter().apply {
            addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
        }
        ContextCompat.registerReceiver(ctx, receiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        registered = true
        // Limpa estado antigo que possa ter ficado preso no sistema (causa comum de BUSY).
        try {
            val ch = channel
            if (ch != null) {
                m.stopPeerDiscovery(ch, null)
                m.cancelConnect(ch, null)
                m.removeGroup(ch, null)
            }
        } catch (_: Exception) {
        }
    }

    fun unregister() {
        if (registered) {
            try {
                ctx.unregisterReceiver(receiver)
            } catch (_: Exception) {
            }
            registered = false
        }
        disconnect()
    }

    fun refreshPeers() = requestPeers()

    /** Pára qualquer pesquisa anterior e só depois inicia outra (evita o erro BUSY). */
    fun discover() {
        val m = manager ?: return
        val ch = channel ?: return
        try {
            m.stopPeerDiscovery(ch, object : WifiP2pManager.ActionListener {
                override fun onSuccess() = doDiscover()
                override fun onFailure(reason: Int) = doDiscover()
            })
        } catch (e: SecurityException) {
            l.onSecurityError()
        }
    }

    private fun doDiscover() {
        val m = manager ?: return
        val ch = channel ?: return
        try {
            m.discoverPeers(ch, object : WifiP2pManager.ActionListener {
                override fun onSuccess() = l.onDiscoveryStarted()
                override fun onFailure(reason: Int) = l.onDiscoveryFailed(reason)
            })
        } catch (e: SecurityException) {
            l.onSecurityError()
        }
    }

    fun connect(device: WifiP2pDevice) {
        val m = manager ?: return
        val ch = channel ?: return
        val cfg = WifiP2pConfig().apply {
            deviceAddress = device.deviceAddress
            wps.setup = WpsInfo.PBC
        }
        l.onConnecting()
        try {
            m.connect(ch, cfg, object : WifiP2pManager.ActionListener {
                override fun onSuccess() {
                    // O resultado real chega por WIFI_P2P_CONNECTION_CHANGED_ACTION.
                }

                override fun onFailure(reason: Int) = l.onConnectFailed(reason)
            })
        } catch (e: SecurityException) {
            l.onSecurityError()
        }
    }

    /** Fecha o servidor, cancela ligações pendentes e remove o grupo Wi-Fi Direct. */
    fun disconnect() {
        socketStarted = false
        try {
            acceptSocket?.close()
        } catch (_: Exception) {
        }
        acceptSocket = null
        val m = manager ?: return
        val ch = channel ?: return
        try {
            m.cancelConnect(ch, null)
            m.removeGroup(ch, null)
        } catch (_: Exception) {
        }
    }

    private fun requestPeers() {
        val m = manager ?: return
        val ch = channel ?: return
        try {
            m.requestPeers(ch) { list -> l.onPeers(list?.deviceList?.toList() ?: emptyList()) }
        } catch (e: SecurityException) {
            l.onSecurityError()
        }
    }

    private fun requestConnection() {
        val m = manager ?: return
        val ch = channel ?: return
        m.requestConnectionInfo(ch) { info: WifiP2pInfo? ->
            if (info != null && info.groupFormed) {
                if (!socketStarted) {
                    socketStarted = true
                    startSocket(info)
                }
            } else if (socketStarted) {
                socketStarted = false
                try {
                    acceptSocket?.close()
                } catch (_: Exception) {
                }
                l.onGroupLost()
            }
        }
    }

    private fun startSocket(info: WifiP2pInfo) {
        val owner = info.isGroupOwner
        val host = info.groupOwnerAddress?.hostAddress
        Thread({
            try {
                val sock: Socket
                if (owner) {
                    val ss = ServerSocket()
                    ss.reuseAddress = true
                    ss.bind(InetSocketAddress(Protocol.PORT))
                    ss.soTimeout = 45000
                    acceptSocket = ss
                    sock = ss.accept()
                    ss.close()
                    acceptSocket = null
                } else {
                    if (host == null) throw IOException("Sem endereço do group owner")
                    var s: Socket? = null
                    var tries = 0
                    while (s == null && tries < 15) {
                        tries++
                        try {
                            val c = Socket()
                            c.connect(InetSocketAddress(host, Protocol.PORT), 3000)
                            s = c
                        } catch (e: IOException) {
                            Thread.sleep(700)
                        }
                    }
                    sock = s ?: throw IOException("Não foi possível ligar ao outro telemóvel")
                }
                sock.tcpNoDelay = true
                handler.post { if (socketStarted) l.onSocketReady(sock, owner) else sock.close() }
            } catch (e: Exception) {
                handler.post {
                    if (socketStarted) {
                        socketStarted = false
                        l.onSocketFailed()
                    }
                }
            }
        }, "p2p-socket").start()
    }
}
