package com.tacticaltalk.app

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor

/** Captura voz (PCM 16 bit, mono, 16 kHz) em tramas de 20 ms, com eco e ruído reduzidos quando o aparelho suporta. */
class AudioRecorder(
    private val onFrame: (ByteArray) -> Unit,
    private val onError: (String) -> Unit
) {
    @Volatile private var running = false
    private var rec: AudioRecord? = null
    private var thread: Thread? = null
    private var aec: AcousticEchoCanceler? = null
    private var ns: NoiseSuppressor? = null

    @SuppressLint("MissingPermission")
    fun start(): Boolean {
        if (running) return true
        val min = AudioRecord.getMinBufferSize(
            Protocol.SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (min <= 0) return false
        val r = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                Protocol.SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                maxOf(min, Protocol.FRAME_BYTES * 4)
            )
        } catch (e: Exception) {
            return false
        }
        if (r.state != AudioRecord.STATE_INITIALIZED) {
            r.release()
            return false
        }
        try {
            if (AcousticEchoCanceler.isAvailable()) aec = AcousticEchoCanceler.create(r.audioSessionId)?.also { it.enabled = true }
            if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(r.audioSessionId)?.also { it.enabled = true }
        } catch (_: Exception) {
        }
        try {
            r.startRecording()
        } catch (e: Exception) {
            r.release()
            return false
        }
        if (r.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
            r.release()
            return false
        }
        rec = r
        running = true
        thread = Thread({
            val buf = ByteArray(Protocol.FRAME_BYTES)
            while (running) {
                var off = 0
                while (running && off < Protocol.FRAME_BYTES) {
                    val n = r.read(buf, off, Protocol.FRAME_BYTES - off)
                    if (n < 0) {
                        if (running) onError("AudioRecord erro $n")
                        running = false
                        break
                    }
                    off += n
                }
                if (running && off == Protocol.FRAME_BYTES) onFrame(buf.copyOf())
            }
        }, "audio-recorder").also { it.start() }
        return true
    }

    fun stop() {
        running = false
        try {
            rec?.stop()
        } catch (_: Exception) {
        }
        try {
            thread?.join(500)
        } catch (_: InterruptedException) {
        }
        try {
            aec?.release()
            ns?.release()
            rec?.release()
        } catch (_: Exception) {
        }
        aec = null
        ns = null
        rec = null
        thread = null
    }
}
